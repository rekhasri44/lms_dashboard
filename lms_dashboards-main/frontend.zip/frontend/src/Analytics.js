import React from 'react';
import { 
  Bell, 
  User, 
  BarChart3, 
  BookOpen, 
  Users, 
  GraduationCap, 
  FileText, 
  Settings,
  TrendingUp,
  Filter,
  RefreshCw,
  Download,
  AlertTriangle
} from 'lucide-react';
import './Analytics.css';

const Analytics = () => {
  return (
    <div className="analytics-container">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon">
              <GraduationCap className="icon-medium" />
            </div>
            <span className="logo-text">EduAdmin</span>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <div className="nav-section-title">Navigation</div>
          <div className="nav-links">
            <a href="/" className="nav-link">
              <BarChart3 className="nav-icon" />
              Overview
            </a>
            <a href="/students" className="nav-link">
              <Users className="nav-icon" />
              Students
            </a>
            <a href="/faculty" className="nav-link">
              <GraduationCap className="nav-icon" />
              Faculty
            </a>
            <a href="/courses" className="nav-link">
              <BookOpen className="nav-icon" />
              Courses
            </a>
            <a href="/analytics" className="nav-link active">
              <BarChart3 className="nav-icon" />
              Analytics
            </a>
            <a href="/reports" className="nav-link">
              <FileText className="nav-icon" />
              Reports
            </a>
            <a href="/settings" className="nav-link">
              <Settings className="nav-icon" />
              Settings
            </a>
          </div>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Header */}
        <header className="header">
          <h1 className="header-title">Analytics & Insights</h1>
          <div className="header-actions">
            <button className="notification-button">
              <Bell className="icon-small" />
              <span className="notification-badge"></span>
            </button>
            <div className="profile-avatar">
              <User className="icon-small" />
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="analytics-main">
          {/* Advanced Analytics Header */}
          <div className="analytics-header">
            <div>
              <h2 className="analytics-title">Advanced Analytics</h2>
              <p className="analytics-subtitle">Comprehensive insights and predictive analytics</p>
            </div>
            <div className="analytics-actions">
              <button className="action-btn">
                <Filter className="icon-small" />
                Filters
              </button>
              <button className="action-btn">
                <RefreshCw className="icon-small" />
                Refresh
              </button>
              <button className="action-btn">
                <Download className="icon-small" />
                Export Report
              </button>
            </div>
          </div>

          {/* Metrics Cards */}
          <div className="metrics-grid">
            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">Student Retention</span>
                <Users className="metric-icon blue" />
              </div>
              <div className="metric-value">94.2%</div>
              <div className="metric-change positive">↗ 2.1% vs last period</div>
            </div>

            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">Course Completion</span>
                <BookOpen className="metric-icon blue" />
              </div>
              <div className="metric-value">91.7%</div>
              <div className="metric-change positive">↗ 1.5% vs last period</div>
            </div>

            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">Avg Class Size</span>
                <TrendingUp className="metric-icon blue" />
              </div>
              <div className="metric-value">28.5</div>
              <div className="metric-change negative">↘ 3.2% vs last period</div>
            </div>

            <div className="metric-card">
              <div className="metric-header">
                <span className="metric-label">Satisfaction Score</span>
                <TrendingUp className="metric-icon blue" />
              </div>
              <div className="metric-value">4.3/5</div>
              <div className="metric-change positive">↗ 0.2% vs last period</div>
            </div>
          </div>

          {/* Charts Row 1 */}
          <div className="charts-row">
            <div className="chart-card">
              <h3 className="chart-title">Resource Utilization</h3>
              <div className="pie-chart-wrapper">
                <svg viewBox="0 0 200 200" className="pie-chart">
                  <circle cx="100" cy="100" r="80" fill="none" stroke="#3b82f6" strokeWidth="60" strokeDasharray="339 424" transform="rotate(-90 100 100)" />
                  <circle cx="100" cy="100" r="80" fill="none" stroke="#10b981" strokeWidth="60" strokeDasharray="102 424" strokeDashoffset="-339" transform="rotate(-90 100 100)" />
                  <circle cx="100" cy="100" r="80" fill="none" stroke="#eab308" strokeWidth="60" strokeDasharray="34 424" strokeDashoffset="-441" transform="rotate(-90 100 100)" />
                </svg>
                <div className="pie-legend">
                  <div className="legend-item">
                    <span className="legend-dot blue"></span>
                    <span>Classrooms: 68%</span>
                  </div>
                  <div className="legend-item">
                    <span className="legend-dot green"></span>
                    <span>Labs: 24%</span>
                  </div>
                  <div className="legend-item">
                    <span className="legend-dot yellow"></span>
                    <span>Library: 8%</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="chart-card">
              <h3 className="chart-title">Grade Distribution</h3>
              <div className="bar-chart">
                <div className="bar-wrapper">
                  <div className="bar" style={{height: '60%'}}></div>
                  <span className="bar-label">A</span>
                </div>
                <div className="bar-wrapper">
                  <div className="bar" style={{height: '85%'}}></div>
                  <span className="bar-label">B</span>
                </div>
                <div className="bar-wrapper">
                  <div className="bar" style={{height: '70%'}}></div>
                  <span className="bar-label">C</span>
                </div>
                <div className="bar-wrapper">
                  <div className="bar" style={{height: '40%'}}></div>
                  <span className="bar-label">D</span>
                </div>
                <div className="bar-wrapper">
                  <div className="bar" style={{height: '25%'}}></div>
                  <span className="bar-label">F</span>
                </div>
              </div>
              <div className="y-axis">
                <span>6000</span>
                <span>4500</span>
                <span>3000</span>
                <span>1500</span>
                <span>0</span>
              </div>
            </div>

            <div className="chart-card">
              <h3 className="chart-title">Faculty Performance</h3>
              <div className="radar-chart">
                <svg viewBox="0 0 200 200">
                  <polygon points="100,30 160,70 160,130 100,170 40,130 40,70" fill="none" stroke="#e5e7eb" strokeWidth="1" />
                  <polygon points="100,50 140,80 140,120 100,150 60,120 60,80" fill="none" stroke="#e5e7eb" strokeWidth="1" />
                  <polygon points="100,70 120,90 120,110 100,130 80,110 80,90" fill="none" stroke="#e5e7eb" strokeWidth="1" />
                  <line x1="100" y1="100" x2="100" y2="30" stroke="#e5e7eb" strokeWidth="1" />
                  <line x1="100" y1="100" x2="160" y2="70" stroke="#e5e7eb" strokeWidth="1" />
                  <line x1="100" y1="100" x2="160" y2="130" stroke="#e5e7eb" strokeWidth="1" />
                  <line x1="100" y1="100" x2="100" y2="170" stroke="#e5e7eb" strokeWidth="1" />
                  <line x1="100" y1="100" x2="40" y2="130" stroke="#e5e7eb" strokeWidth="1" />
                  <line x1="100" y1="100" x2="40" y2="70" stroke="#e5e7eb" strokeWidth="1" />
                  <polygon points="100,36 152,74 152,126 100,156 48,126 48,74" fill="#3b82f6" fillOpacity="0.3" stroke="#3b82f6" strokeWidth="2" />
                </svg>
                <div className="radar-labels">
                  <span style={{top: '10%', left: '50%'}}>Research</span>
                  <span style={{top: '25%', right: '5%'}}>Satisfaction</span>
                  <span style={{bottom: '25%', right: '5%'}}>Innovation</span>
                  <span style={{bottom: '10%', left: '50%'}}>Pass Rate</span>
                  <span style={{bottom: '25%', left: '5%'}}>Grading</span>
                  <span style={{top: '25%', left: '5%'}}>Feedback</span>
                </div>
              </div>
            </div>
          </div>

          {/* Charts Row 2 */}
          <div className="charts-row2">
            <div className="chart-card2">
              <h3 className="chart-title">Dropout Risk by Department</h3>
              <div className="risk-list">
                <div className="risk-item">
                  <div className="risk-info">
                    <span className="dept-name">Computer Science</span>
                    <span className="student-count">1247 students</span>
                  </div>
                  <div className="risk-badge-wrapper">
                    <span className="risk-percent green">15%</span>
                    <span className="risk-badge low">Low Risk</span>
                  </div>
                </div>
                <div className="risk-item">
                  <div className="risk-info">
                    <span className="dept-name">Engineering</span>
                    <span className="student-count">2134 students</span>
                  </div>
                  <div className="risk-badge-wrapper">
                    <span className="risk-percent yellow">23%</span>
                    <span className="risk-badge medium">Medium Risk</span>
                  </div>
                </div>
                <div className="risk-item">
                  <div className="risk-info">
                    <span className="dept-name">Business</span>
                    <span className="student-count">892 students</span>
                  </div>
                  <div className="risk-badge-wrapper">
                    <span className="risk-percent green">8%</span>
                    <span className="risk-badge low">Low Risk</span>
                  </div>
                </div>
                <div className="risk-item">
                  <div className="risk-info">
                    <span className="dept-name">Physics</span>
                    <span className="student-count">674 students</span>
                  </div>
                  <div className="risk-badge-wrapper">
                    <span className="risk-percent red">35%</span>
                    <span className="risk-badge high">High Risk</span>
                  </div>
                </div>
                <div className="risk-item">
                  <div className="risk-info">
                    <span className="dept-name">Mathematics</span>
                    <span className="student-count">456 students</span>
                  </div>
                  <div className="risk-badge-wrapper">
                    <span className="risk-percent green">18%</span>
                    <span className="risk-badge low">Low Risk</span>
                  </div>
                </div>
                <div className="risk-item">
                  <div className="risk-info">
                    <span className="dept-name">Literature</span>
                    <span className="student-count">334 students</span>
                  </div>
                  <div className="risk-badge-wrapper">
                    <span className="risk-percent green">12%</span>
                    <span className="risk-badge low">Low Risk</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="chart-card2">
              <h3 className="chart-title">Pass Rates by Subject</h3>
              <div className="pass-rates">
                <div className="pass-rate-item">
                  <div className="pass-rate-header">
                    <span>Mathematics</span>
                    <span className="pass-percent">87%</span>
                  </div>
                  <div className="pass-rate-bar">
                    <div className="pass-rate-fill" style={{width: '87%'}}></div>
                  </div>
                </div>
                <div className="pass-rate-item">
                  <div className="pass-rate-header">
                    <span>Physics</span>
                    <span className="pass-percent">79%</span>
                  </div>
                  <div className="pass-rate-bar">
                    <div className="pass-rate-fill" style={{width: '79%'}}></div>
                  </div>
                </div>
                <div className="pass-rate-item">
                  <div className="pass-rate-header">
                    <span>Chemistry</span>
                    <span className="pass-percent">91%</span>
                  </div>
                  <div className="pass-rate-bar">
                    <div className="pass-rate-fill" style={{width: '91%'}}></div>
                  </div>
                </div>
                <div className="pass-rate-item">
                  <div className="pass-rate-header">
                    <span>Computer Science</span>
                    <span className="pass-percent">94%</span>
                  </div>
                  <div className="pass-rate-bar">
                    <div className="pass-rate-fill" style={{width: '94%'}}></div>
                  </div>
                </div>
                <div className="pass-rate-item">
                  <div className="pass-rate-header">
                    <span>English</span>
                    <span className="pass-percent">96%</span>
                  </div>
                  <div className="pass-rate-bar">
                    <div className="pass-rate-fill" style={{width: '96%'}}></div>
                  </div>
                </div>
                <div className="pass-rate-item">
                  <div className="pass-rate-header">
                    <span>History</span>
                    <span className="pass-percent">89%</span>
                  </div>
                  <div className="pass-rate-bar">
                    <div className="pass-rate-fill" style={{width: '89%'}}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Course Demand Forecast */}
          <div className="chart-card full-width">
            <h3 className="chart-title">Course Demand Forecast</h3>
            <div className="line-chart-container">
              <div className="line-legend">
                <div className="legend-item">
                  <span className="legend-dot blue"></span>
                  <span>Computer Science</span>
                </div>
                <div className="legend-item">
                  <span className="legend-dot green"></span>
                  <span>Engineering</span>
                </div>
                <div className="legend-item">
                  <span className="legend-dot yellow"></span>
                  <span>Business</span>
                </div>
                <div className="legend-item">
                  <span className="legend-dot orange"></span>
                  <span>Mathematics</span>
                </div>
              </div>
              <svg viewBox="0 0 600 200" className="line-chart">
                <defs>
                  <pattern id="grid" width="100" height="50" patternUnits="userSpaceOnUse">
                    <path d="M 100 0 L 0 0 0 50" fill="none" stroke="#e5e7eb" strokeWidth="1"/>
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
                <polyline fill="none" stroke="#3b82f6" strokeWidth="2" points="0,150 100,140 200,125 300,110 400,95 500,85 600,75"/>
                <polyline fill="none" stroke="#10b981" strokeWidth="2" points="0,175 100,170 200,165 300,160 400,155 500,150 600,145"/>
                <polyline fill="none" stroke="#eab308" strokeWidth="2" points="0,185 100,180 200,175 300,170 400,165 500,160 600,155"/>
                <polyline fill="none" stroke="#f97316" strokeWidth="2" points="0,190 100,188 200,185 300,182 400,180 500,175 600,170"/>
              </svg>
              <div className="x-axis">
                <span>Fall 22</span>
                <span>Spring 23</span>
                <span>Fall 23</span>
                <span>Spring 24</span>
                <span>Fall 24</span>
                <span>Spring 25</span>
              </div>
              <div className="y-axis-left">
                <span>400</span>
                <span>300</span>
                <span>200</span>
                <span>100</span>
                <span>0</span>
              </div>
            </div>
          </div>

          {/* Performance Benchmarking & Student Engagement */}
          <div className="charts-row2">
            <div className="chart-card2">
              <h3 className="chart-title">Performance Benchmarking</h3>
              <div className="benchmark-list">
                <div className="benchmark-item">
                  <span className="benchmark-label">Pass Rate</span>
                  <div className="benchmark-bar-wrapper">
                    <div className="benchmark-bar">
                      <div className="benchmark-fill" style={{width: '94%'}}></div>
                    </div>
                    <span className="benchmark-value">0.94</span>
                  </div>
                </div>
                <div className="benchmark-item">
                  <span className="benchmark-label">Student Satisfaction</span>
                  <div className="benchmark-bar-wrapper">
                    <div className="benchmark-bar">
                      <div className="benchmark-fill" style={{width: '88%'}}></div>
                    </div>
                    <span className="benchmark-value">0.88</span>
                  </div>
                </div>
                <div className="benchmark-item">
                  <span className="benchmark-label">Faculty Ratio</span>
                  <div className="benchmark-bar-wrapper">
                    <div className="benchmark-bar">
                      <div className="benchmark-fill" style={{width: '75%'}}></div>
                    </div>
                    <span className="benchmark-value">0.75</span>
                  </div>
                </div>
                <div className="benchmark-item">
                  <span className="benchmark-label">Research Output</span>
                  <div className="benchmark-bar-wrapper">
                    <div className="benchmark-bar">
                      <div className="benchmark-fill" style={{width: '82%'}}></div>
                    </div>
                    <span className="benchmark-value">0.82</span>
                  </div>
                </div>
                <div className="benchmark-item">
                  <span className="benchmark-label">Employment Rate</span>
                  <div className="benchmark-bar-wrapper">
                    <div className="benchmark-bar">
                      <div className="benchmark-fill" style={{width: '91%'}}></div>
                    </div>
                    <span className="benchmark-value">0.91</span>
                  </div>
                </div>
              </div>
              <div className="x-axis-benchmark">
                <span>0</span>
                <span>0.25</span>
                <span>0.5</span>
                <span>0.75</span>
                <span>1</span>
              </div>
            </div>

            <div className="chart-card2">
              <h3 className="chart-title">Student Engagement Trends</h3>
              <div className="engagement-legend">
                <div className="legend-item">
                  <span className="legend-dot blue"></span>
                  <span>Attendance</span>
                </div>
                <div className="legend-item">
                  <span className="legend-dot green"></span>
                  <span>Assignment Submission</span>
                </div>
                <div className="legend-item">
                  <span className="legend-dot yellow"></span>
                  <span>Discussion Participation</span>
                </div>
              </div>
              <svg viewBox="0 0 400 150" className="engagement-chart">
                <defs>
                  <pattern id="grid2" width="66.67" height="37.5" patternUnits="userSpaceOnUse">
                    <path d="M 66.67 0 L 0 0 0 37.5" fill="none" stroke="#e5e7eb" strokeWidth="1"/>
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid2)" />
                <polyline fill="none" stroke="#3b82f6" strokeWidth="2" points="0,30 66.67,27 133.33,25 200,24 266.67,22 333.33,20 400,18"/>
                <polyline fill="none" stroke="#10b981" strokeWidth="2" points="0,75 66.67,65 133.33,60 200,55 266.67,50 333.33,45 400,18"/>
                <polyline fill="none" stroke="#eab308" strokeWidth="2" points="0,112 66.67,105 133.33,105 200,100 266.67,85 333.33,75 400,93"/>
              </svg>
              <div className="x-axis">
                <span>Jan</span>
                <span>Feb</span>
                <span>Mar</span>
                <span>Apr</span>
                <span>May</span>
                <span>Jun</span>
              </div>
              <div className="y-axis-left">
                <span>100</span>
                <span>75</span>
                <span>50</span>
                <span>25</span>
                <span>0</span>
              </div>
            </div>
          </div>

          {/* Institutional Trends & Department Performance */}
          <div className="charts-row2">
            <div className="chart-card2">
              <h3 className="chart-title">Institutional Trends</h3>
              <svg viewBox="0 0 400 200" className="trend-chart">
                <rect x="40" y="40" width="60" height="120" fill="#3b82f6"/>
                <rect x="120" y="35" width="60" height="125" fill="#3b82f6"/>
                <rect x="200" y="30" width="60" height="130" fill="#3b82f6"/>
                <rect x="280" y="32" width="60" height="128" fill="#3b82f6"/>
                <rect x="360" y="28" width="60" height="132" fill="#3b82f6"/>
                <polyline fill="none" stroke="#10b981" strokeWidth="2" points="70,100 150,95 230,90 310,92 390,88"/>
                <circle cx="70" cy="100" r="4" fill="#10b981"/>
                <circle cx="150" cy="95" r="4" fill="#10b981"/>
                <circle cx="230" cy="90" r="4" fill="#10b981"/>
                <circle cx="310" cy="92" r="4" fill="#10b981"/>
                <circle cx="390" cy="88" r="4" fill="#10b981"/>
              </svg>
              <div className="x-axis">
                <span>Aug</span>
                <span>Sep</span>
                <span>Oct</span>
                <span>Nov</span>
                <span>Dec</span>
              </div>
            </div>

            <div className="chart-card2">
              <h3 className="chart-title">Department Performance</h3>
              <div className="donut-chart-wrapper">
                <svg viewBox="0 0 200 200" className="donut-chart">
                  <circle cx="100" cy="100" r="70" fill="none" stroke="#3b82f6" strokeWidth="40" strokeDasharray="123 439" transform="rotate(-90 100 100)" />
                  <circle cx="100" cy="100" r="70" fill="none" stroke="#10b981" strokeWidth="40" strokeDasharray="70 439" strokeDashoffset="-123" transform="rotate(-90 100 100)" />
                  <circle cx="100" cy="100" r="70" fill="none" stroke="#eab308" strokeWidth="40" strokeDasharray="79 439" strokeDashoffset="-193" transform="rotate(-90 100 100)" />
                  <circle cx="100" cy="100" r="70" fill="none" stroke="#3b82f6" strokeWidth="40" strokeDasharray="70 439" strokeDashoffset="-272" transform="rotate(-90 100 100)" />
                </svg>
                <div className="donut-legend">
                  <div className="legend-item">
                    <span className="legend-dot blue"></span>
                    <span>Computer Science: 28%</span>
                  </div>
                  <div className="legend-item">
                    <span className="legend-dot green"></span>
                    <span>Mathematics: 22%</span>
                  </div>
                  <div className="legend-item">
                    <span className="legend-dot yellow"></span>
                    <span>Physics: 18%</span>
                  </div>
                  <div className="legend-item">
                    <span className="legend-dot blue"></span>
                    <span>Biology: 16%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Risk Assessment Dashboard */}
          <div className="risk-dashboard">
            <div className="risk-header">
              <AlertTriangle className="icon-medium" />
              <h3>Risk Assessment Dashboard</h3>
            </div>
            <div className="risk-cards">
              <div className="risk-card">
                <div className="risk-card-header">
                  <span className="risk-card-title">High Dropout Risk</span>
                  <span className="risk-status warning">warning</span>
                </div>
                <div className="risk-card-body">
                  <div className="risk-numbers">
                    <span className="current">Current: 342</span>
                    <span className="target">Target: 300</span>
                  </div>
                  <div className="risk-progress-bar">
                    <div className="risk-progress-fill warning" style={{width: '85%'}}></div>
                  </div>
                  <span className="over-target">42 over target</span>
                </div>
              </div>

              <div className="risk-card">
                <div className="risk-card-header">
                  <span className="risk-card-title">Low GPA (&lt;2.5)</span>
                  <span className="risk-status warning">warning</span>
                </div>
                <div className="risk-card-body">
                  <div className="risk-numbers">
                    <span className="current">Current: 156</span>
                    <span className="target">Target: 120</span>
                  </div>
                  <div className="risk-progress-bar">
                    <div className="risk-progress-fill warning" style={{width: '78%'}}></div>
                  </div>
                  <span className="over-target">36 over target</span>
                </div>
              </div>

              <div className="risk-card">
                <div className="risk-card-header">
                  <span className="risk-card-title">Poor Attendance</span>
                  <span className="risk-status critical">critical</span>
                </div>
                <div className="risk-card-body">
                  <div className="risk-numbers">
                    <span className="current">Current: 89</span>
                    <span className="target">Target: 50</span>
                  </div>
                  <div className="risk-progress-bar">
                    <div className="risk-progress-fill critical" style={{width: '89%'}}></div>
                  </div>
                  <span className="over-target">39 over target</span>
                </div>
              </div>

              <div className="risk-card">
                <div className="risk-card-header">
                  <span className="risk-card-title">Financial Issues</span>
                  <span className="risk-status warning">warning</span>
                </div>
                <div className="risk-card-body">
                  <div className="risk-numbers">
                    <span className="current">Current: 234</span>
                    <span className="target">Target: 200</span>
                  </div>
                  <div className="risk-progress-bar">
                    <div className="risk-progress-fill warning" style={{width: '87%'}}></div>
                  </div>
                  <span className="over-target">34 over target</span>
                </div>
              </div>
            </div>
          </div>

          {/* Predictive Insights */}
          <div className="insights-section">
            <h3 className="section-title">Predictive Insights & Recommendations</h3>
            <div className="insights-grid">
              <div className="insight-card opportunity">
                <div className="insight-badge">Opportunity</div>
                <p className="insight-text">
                  Mathematics department shows strong growth potential. Consider expanding course offerings.
                </p>
              </div>
              <div className="insight-card alert">
                <div className="insight-badge">Alert</div>
                <p className="insight-text">
                  Physics courses have declining enrollment. Review curriculum relevance and marketing.
                </p>
              </div>
              <div className="insight-card critical">
                <div className="insight-badge">Critical</div>
                <p className="insight-text">
                  342 students at high dropout risk. Immediate intervention programs recommended.
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Analytics;