import React, { useState } from 'react';
import { 
  Bell, 
  User, 
  BarChart3, 
  BookOpen, 
  Users, 
  GraduationCap, 
  FileText, 
  Settings,
  Filter,
  Plus,
  Search,
  Eye,
  Download,
  Send,
  Calendar,
  DollarSign,
  TrendingUp
} from 'lucide-react';
import './Reports.css';

const Reports = () => {
  const [showScheduled, setShowScheduled] = useState(false);

  const recentReports = [
    {
      id: 'RPT001',
      name: 'Student Enrollment Report',
      type: 'Academic',
      size: '2.4 MB',
      downloads: 23,
      generated: '2024-01-15 09:30',
      generatedBy: 'System',
      status: 'completed'
    },
    {
      id: 'RPT002',
      name: 'Faculty Performance Analysis',
      type: 'HR',
      size: '1.8 MB',
      downloads: 15,
      generated: '2024-01-14 14:22',
      generatedBy: 'Dr. Admin',
      status: 'completed'
    },
    {
      id: 'RPT003',
      name: 'Financial Summary Q4',
      type: 'Financial',
      size: '3.2 MB',
      downloads: 42,
      generated: '2024-01-13 11:45',
      generatedBy: 'Finance Dept',
      status: 'completed'
    },
    {
      id: 'RPT004',
      name: 'Course Completion Rates',
      type: 'Academic',
      size: '1.2 MB',
      downloads: 0,
      generated: '2024-01-12 08:00',
      generatedBy: 'System',
      status: 'processing'
    },
    {
      id: 'RPT005',
      name: 'Risk Assessment Dashboard',
      type: 'Analytics',
      size: '0 MB',
      downloads: 0,
      generated: '2024-01-11 16:15',
      generatedBy: 'System',
      status: 'failed'
    }
  ];

  const scheduledReports = [
    {
      name: 'Weekly Attendance Report',
      schedule: 'Every Monday at 8:00 AM',
      nextRun: '2024-01-22 08:00',
      recipients: 2,
      status: 'active'
    },
    {
      name: 'Monthly Grade Distribution',
      schedule: '1st day of each month at 9:00 AM',
      nextRun: '2024-02-01 09:00',
      recipients: 2,
      status: 'active'
    },
    {
      name: 'Quarterly Budget Analysis',
      schedule: 'First Monday of quarter at 10:00 AM',
      nextRun: '2024-04-01 10:00',
      recipients: 2,
      status: 'paused'
    }
  ];

  const templates = [
    {
      icon: <Users className="template-icon" />,
      title: 'Student Performance Summary',
      description: 'Comprehensive overview of student academic performance',
      category: 'Academic',
      fields: 4
    },
    {
      icon: <BookOpen className="template-icon" />,
      title: 'Course Analytics Report',
      description: 'Detailed analysis of course enrollment and completion',
      category: 'Academic',
      fields: 4
    },
    {
      icon: <DollarSign className="template-icon" />,
      title: 'Financial Overview',
      description: 'Complete financial status and budget analysis',
      category: 'Financial',
      fields: 4
    },
    {
      icon: <TrendingUp className="template-icon" />,
      title: 'Institutional Analytics',
      description: 'High-level institutional performance metrics',
      category: 'Analytics',
      fields: 4
    }
  ];

  return (
    <div className="reports-container">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon">
              <GraduationCap className="icon-medium" />
            </div>
            <span className="logo-text">EduAdmin</span>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <div className="nav-section-title">Navigation</div>
          <div className="nav-links">
            <a href="/" className="nav-link">
              <BarChart3 className="nav-icon" />
              Overview
            </a>
            <a href="/students" className="nav-link">
              <Users className="nav-icon" />
              Students
            </a>
            <a href="/faculty" className="nav-link">
              <GraduationCap className="nav-icon" />
              Faculty
            </a>
            <a href="/courses" className="nav-link">
              <BookOpen className="nav-icon" />
              Courses
            </a>
            <a href="/analytics" className="nav-link">
              <BarChart3 className="nav-icon" />
              Analytics
            </a>
            <a href="/reports" className="nav-link active">
              <FileText className="nav-icon" />
              Reports
            </a>
            <a href="/settings" className="nav-link">
              <Settings className="nav-icon" />
              Settings
            </a>
          </div>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Header */}
        <header className="header">
          <h1 className="header-title">Reports & Analytics</h1>
          <div className="header-actions">
            <button className="notification-button">
              <Bell className="icon-small" />
              <span className="notification-badge"></span>
            </button>
            <div className="profile-avatar">
              <User className="icon-small" />
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="reports-main">
          {/* Stats Cards */}
              <div className="stats-grid">
                <div className="stat-card">
                  <div className="stat-icon blue">
                    <FileText className="icon-medium" />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">127</div>
                    <div className="stat-label">Generated Reports</div>
                    <div className="stat-sublabel">this month</div>
                  </div>
                </div>

                <div className="stat-card">
                  <div className="stat-icon blue">
                    <Calendar className="icon-medium" />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">23</div>
                    <div className="stat-label">Scheduled Reports</div>
                    <div className="stat-sublabel">active</div>
                  </div>
                </div>

                <div className="stat-card">
                  <div className="stat-icon green">
                    <TrendingUp className="icon-medium" />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">89%</div>
                    <div className="stat-label">Automated Reports</div>
                    <div className="stat-sublabel">success rate</div>
                  </div>
                </div>

                <div className="stat-card">
                  <div className="stat-icon blue">
                    <BarChart3 className="icon-medium" />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">99.7%</div>
                    <div className="stat-label">Data Coverage</div>
                    <div className="stat-sublabel">accuracy</div>
                  </div>
                </div>
              </div>

              {/* Recent Reports Section */}
              <div className="reports-section">
                <div className="section-header">
                  <h2 className="section-title">Recent Reports</h2>
                  <div className="section-actions">
                    <button className="btn-secondary">
                      <Filter className="icon-small" />
                      Filter
                    </button>
                    <button className="btn-primary">
                      <Plus className="icon-small" />
                      Generate Report
                    </button>
                  </div>
                </div>

                <div className="search-bar">
                  <Search className="search-icon" />
                  <input type="text" placeholder="Search reports..." className="search-input" />
                </div>

                <div className="reports-table">
                  <table>
                    <thead>
                      <tr>
                        <th>Report</th>
                        <th>Type</th>
                        <th>Generated</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentReports.map((report) => (
                        <tr key={report.id}>
                          <td>
                            <div className="report-info">
                              <div className="report-name">{report.name}</div>
                              <div className="report-meta">
                                {report.id} • {report.size} • {report.downloads} downloads
                              </div>
                            </div>
                          </td>
                          <td>
                            <span className={`type-badge ${report.type.toLowerCase()}`}>
                              {report.type}
                            </span>
                          </td>
                          <td>
                            <div className="generated-info">
                              <div>{report.generated}</div>
                              <div className="generated-by">by {report.generatedBy}</div>
                            </div>
                          </td>
                          <td>
                            <span className={`status-badge ${report.status}`}>
                              {report.status === 'completed' && '✓'}
                              {report.status === 'processing' && '⟳'}
                              {report.status === 'failed' && '⚠'}
                              {report.status}
                            </span>
                          </td>
                          <td>
                            <div className="action-buttons">
                              <button className="action-btn" title="View">
                                <Eye className="icon-small" />
                              </button>
                              <button className="action-btn" title="Download">
                                <Download className="icon-small" />
                              </button>
                              <button className="action-btn" title="Share">
                                <Send className="icon-small" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Report Templates */}
              <div className="templates-section">
                <h2 className="section-title">Report Templates</h2>
                <div className="templates-grid">
                  {templates.map((template, index) => (
                    <div key={index} className="template-card">
                      <div className="template-header">
                        {template.icon}
                        <div className="template-info">
                          <div className="template-title">{template.title}</div>
                          <div className="template-description">{template.description}</div>
                        </div>
                      </div>
                      <div className="template-footer">
                        <div className="template-meta">
                          <span className={`category-badge ${template.category.toLowerCase()}`}>
                            {template.category}
                          </span>
                          <span className="field-count">{template.fields} fields</span>
                        </div>
                        <button className="btn-use-template">Use Template</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
           
          {!showScheduled ? (
  <>
    {/* Recent Reports + Templates */}
    {/* your existing Recent Reports and Templates JSX here */}
  </>
) : (
  /* Scheduled Reports View */
  <div className="scheduled-section">
    <div className="section-header">
      <h2 className="section-title">Scheduled Reports</h2>
      <button className="btn-primary">
        <Plus className="icon-small" />
        Schedule Report
      </button>
    </div>

    <div className="scheduled-list">
      {scheduledReports.map((report, index) => (
        <div key={index} className="scheduled-card">
          <div className="scheduled-icon">
            <Calendar className="icon-medium" />
          </div>
          <div className="scheduled-info">
            <div className="scheduled-title">{report.name}</div>
            <div className="scheduled-schedule">{report.schedule}</div>
            <div className="scheduled-next">Next run: {report.nextRun}</div>
          </div>
          <div className="scheduled-meta">
            <div className="recipients-info">{report.recipients} recipients</div>
            <span className={`status-tag ${report.status}`}>{report.status}</span>
          </div>
          <div className="scheduled-actions">
            <button className="action-btn" title="View">
              <Eye className="icon-small" />
            </button>
            <button className="action-btn" title="Share">
              <Send className="icon-small" />
            </button>
          </div>
        </div>
      ))}
    </div>
  </div>
)}


          {/* Toggle Button for Demo */}
          <button 
            onClick={() => setShowScheduled(!showScheduled)}
            className="demo-toggle"
          >
            {showScheduled ? 'Show Recent Reports' : 'Show Scheduled Reports'}
          </button>
        </main>
      </div>
    </div>
  );
};

export default Reports;