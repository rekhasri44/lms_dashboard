import React, { useState } from 'react';
import { Mail, Phone, MoreVertical, Download, Filter, UserPlus } from 'lucide-react';
import { 
  Bell, 
  User, 
  BarChart3, 
  BookOpen, 
  Users, 
  GraduationCap, 
  FileText, 
  Settings,
  Info,
  X,
  CheckCircle,
  AlertTriangle,
  Calendar
} from 'lucide-react';
import './StudentManagement.css';

const StudentManagement = () => {
  const [students] = useState([
    {
      id: 'STU001',
      name: 'Alex Chen',
      email: 'alex.chen@university.edu',
      department: 'Computer Science',
      year: 'Junior',
      gpa: 3.7,
      credits: 98,
      status: 'active'
    },
    {
      id: 'STU002',
      name: 'Maria Rodriguez',
      email: 'maria.rodriguez@university.edu',
      department: 'Mathematics',
      year: 'Senior',
      gpa: 3.9,
      credits: 118,
      status: 'active'
    },
    {
      id: 'STU003',
      name: 'James Wilson',
      email: 'james.wilson@university.edu',
      department: 'Physics',
      year: 'Sophomore',
      gpa: 2.3,
      credits: 52,
      status: 'probation'
    },
    {
      id: 'STU004',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@university.edu',
      department: 'Biology',
      year: 'Senior',
      gpa: 3.8,
      credits: 112,
      status: 'active'
    },
    {
      id: 'STU005',
      name: 'Michael Davis',
      email: 'michael.davis@university.edu',
      department: 'Chemistry',
      year: 'Freshman',
      gpa: 3.2,
      credits: 28,
      status: 'active'
    }
  ]);

  return (
    <div className="student-management">
        <div className="sidebar">
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon">
              <GraduationCap className="icon-medium" />
            </div>

         
            
          
            <span className="logo-text">EduAdmin</span>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <div className="nav-section-title">
            Navigation
          </div>
          <div className="nav-links">
            <a href="/" className="nav-link active">
              <BarChart3 className="nav-icon" />
              Overview
            </a>
            <a href="/student" className="nav-link">
              <Users className="nav-icon" />
              Students
            </a>
            <a href="/faculty" className="nav-link">
              <GraduationCap className="nav-icon" />
              Faculty
            </a>
            <a href="/course" className="nav-link">
              <BookOpen className="nav-icon" />
              Courses
            </a>
            <a href="/analytics" className="nav-link">
                          <BarChart3 className="nav-icon" />
                          Analytics
                        </a>
                        <a href="/reports" className="nav-link">
                          <FileText className="nav-icon" />
                          Reports
                        </a>
                        <a href="/settings" className="nav-link">
                          <Settings className="nav-icon" />
                          Settings
                        </a>
          </div>
        </nav>
      </div>
      <div className='right'>
      <div className="sm-header">
        <h1>Student Management</h1>
        <div className="sm-header-actions">
          <span className="notification-dot"></span>
          <div className="user-avatar"></div>
        </div>
      </div>

      <div className="sm-stats">
        <div className="sm-stat-card">
          <div className="sm-stat-label">Total Students</div>
          <div className="sm-stat-value">12,847</div>
          <div className="sm-stat-change positive">↑ 8.2% from last semester</div>
        </div>
        <div className="sm-stat-card">
          <div className="sm-stat-label">New Enrollments</div>
          <div className="sm-stat-value">1,247</div>
          <div className="sm-stat-change positive">↑ 12.5% from last semester</div>
        </div>
        <div className="sm-stat-card">
          <div className="sm-stat-label">At-Risk Students</div>
          <div className="sm-stat-value">342</div>
          <div className="sm-stat-change negative">↑ 5.2% from last semester</div>
        </div>
        <div className="sm-stat-card">
          <div className="sm-stat-label">Graduation Rate</div>
          <div className="sm-stat-value">89.3%</div>
          <div className="sm-stat-change positive">↑ 2.1% from last semester</div>
        </div>
      </div>

      <div className="sm-directory">
        <div className="sm-directory-header">
          <h2>Student Directory</h2>
          <div className="sm-directory-actions">
            <button className="sm-btn sm-btn-secondary">
              <Filter size={16} /> Filter
            </button>
            <button className="sm-btn sm-btn-secondary">
              <Download size={16} /> Export
            </button>
            <button className="sm-btn sm-btn-primary">
              <UserPlus size={16} /> Add Student
            </button>
          </div>
        </div>

        <div className="sm-search">
          <input type="text" placeholder="Search students by name, ID, or email..." />
        </div>

        <div className="sm-table">
          <div className="sm-table-header">
            <div>Student</div>
            <div>Department</div>
            <div>Year</div>
            <div>GPA</div>
            <div>Credits</div>
            <div>Status</div>
            <div>Actions</div>
          </div>
          {students.map(student => (
            <div key={student.id} className="sm-table-row">
              <div className="sm-student-info">
                <div className="sm-student-name">{student.name}</div>
                <div className="sm-student-id">{student.id}</div>
                <div className="sm-student-email">{student.email}</div>
              </div>
              <div>{student.department}</div>
              <div>{student.year}</div>
              <div className={student.gpa < 2.5 ? 'sm-gpa-low' : 'sm-gpa-good'}>{student.gpa}</div>
              <div>{student.credits}</div>
              <div>
                <span className={`sm-status-badge ${student.status}`}>{student.status}</span>
              </div>
              <div className="sm-actions">
                <button className="sm-action-btn"><Mail size={16} /></button>
                <button className="sm-action-btn"><Phone size={16} /></button>
                <button className="sm-action-btn"><MoreVertical size={16} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
      </div>
    </div>
  );
};

export default StudentManagement;