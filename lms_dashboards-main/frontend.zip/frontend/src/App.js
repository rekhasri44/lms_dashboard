import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import EduDashboard from "./EduDashboard";
import "./App.css";
import StudentManagement from "./StudentManagement";
import FacultyManagement from "./FacultyManagement";
import CourseManagement from "./CourseManagement";
import Analytics from "./Analytics";
import Reports from "./Reports";
import SettingsPage from "./Settings";
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<EduDashboard />} />
        <Route path="/student" element={<StudentManagement/>}/>
        <Route path="/faculty" element={<FacultyManagement/>}/>
        <Route path="/course" element={<CourseManagement/>}/>
        <Route path="/analytics" element={<Analytics/>}/>
        <Route path="/reports" element={<Reports/>}/>
          <Route path="/settings" element={<SettingsPage/>}/>
      </Routes>
    </Router>
  );
}

export default App;
