import React, { useState } from 'react';
import { 
  Bell, 
  User, 
  BarChart3, 
  BookOpen, 
  Users, 
  GraduationCap, 
  FileText, 
  Settings,
  Info,
  X,
  CheckCircle,
  AlertTriangle,
  Calendar
} from 'lucide-react';
import './EduDashboard.css';

const EduDashboard = () => {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'info',
      title: 'New Course Registration Opens',
      message: 'Registration for Summer 2024 courses begins Monday, January 22nd at 8:00 AM. Priority registration for seniors starts today.',
      audience: 'Students & Advisors',
      time: '2024-01-15 09:00',
      expires: '2024-01-25',
      author: 'Academic Office',
      status: 'active'
    },
    {
      id: 2,
      type: 'success',
      title: 'Library Hours Extended',
      message: 'The library will now be open 24/7 during finals week (January 29 - February 9) to support student studying.',
      audience: 'Students',
      time: '2024-01-14 16:45',
      expires: '2024-02-10',
      author: 'Library Services',
      status: 'active'
    },
    {
      id: 3,
      type: 'warning',
      title: 'Parking Restriction Notice',
      message: 'Lot C will be closed January 20-22 for repaving. Alternative parking available in Lots D and E.',
      audience: 'Faculty & Staff',
      time: '2024-01-13 11:20',
      expires: '2024-01-23',
      author: 'Campus Services',
      status: 'active'
    },
    {
      id: 4,
      type: 'info',
      title: 'Spring Career Fair',
      message: 'The Spring Career Fair will be held February 15th in the Student Union. 150+ employers confirmed.',
      audience: 'Students',
      time: '2024-01-12 13:15',
      expires: '2024-02-16',
      author: 'Career Services',
      status: 'active'
    }
  ]);

  const removeNotification = (id) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const getIcon = (type) => {
    switch(type) {
      case 'info': return <Info className="icon-small" />;
      case 'success': return <CheckCircle className="icon-small" />;
      case 'warning': return <AlertTriangle className="icon-small" />;
      default: return <Info className="icon-small" />;
    }
  };

  const activeNotifications = notifications.filter(n => n.status === 'active');

  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon">
              <GraduationCap className="icon-medium" />
            </div>

         
            
          
            <span className="logo-text">EduAdmin</span>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <div className="nav-section-title">
            Navigation
          </div>
          <div className="nav-links">
            <a href="/" className="nav-link active">
              <BarChart3 className="nav-icon" />
              Overview
            </a>
            <a href="/student" className="nav-link">
              <Users className="nav-icon" />
              Students
            </a>
            <a href="/faculty" className="nav-link">
              <GraduationCap className="nav-icon" />
              Faculty
            </a>
            <a href="/course" className="nav-link">
              <BookOpen className="nav-icon" />
              Courses
            </a>
            <a href="/analytics" className="nav-link">
              <BarChart3 className="nav-icon" />
              Analytics
            </a>
            <a href="/reports" className="nav-link">
              <FileText className="nav-icon" />
              Reports
            </a>
            <a href="/settings" className="nav-link">
              <Settings className="nav-icon" />
              Settings
            </a>
          </div>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Header */}
        <header className="header">
          <h1 className="header-title">Educational Dashboard</h1>
          <div className="header-actions">
            <button className="notification-button">
              <Bell className="icon-small" />
              <span className="notification-badge"></span>
            </button>
            <div className="profile-avatar">
              <User className="icon-small" />
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="main-content-area">
          {/* System Maintenance Alert */}
          <div className="system-alert maintenance-alert">
            <div className="alert-content">
              <AlertTriangle className="alert-icon" />
              <div className="alert-body">
                <h3 className="alert-title">System Maintenance Scheduled</h3>
                <p className="alert-message">
                  The student portal will be unavailable tomorrow from 2:00 AM to 4:00 AM for scheduled maintenance.
                </p>
                <p className="alert-meta">IT Administration • 2024-01-16 14:30</p>
              </div>
              <button className="alert-close">
                <X className="icon-small" />
              </button>
            </div>
          </div>

          {/* System Announcements */}
          <div className="announcements-container">
            <div className="announcements-header">
              <div className="announcements-title-section">
                <Calendar className="icon-medium" />
                <h2 className="announcements-title">System Announcements</h2>
              </div>
              <div className="announcements-actions">
                <span className="active-count">{activeNotifications.length} active</span>
                <button className="create-announcement-btn">
                  Create Announcement
                </button>
              </div>
            </div>

            <div className="announcements-list">
              {notifications.map((notification) => (
                <div key={notification.id} className="announcement-item">
                  <div className="announcement-content">
                    <div className="announcement-icon-wrapper">
                      <div className={`announcement-icon ${notification.type}`}>
                        {getIcon(notification.type)}
                      </div>
                    </div>
                    <div className="announcement-body">
                      <h3 className="announcement-title">{notification.title}</h3>
                      <p className="announcement-message">{notification.message}</p>
                      <div className="announcement-meta">
                        <span className="meta-item">
                          <Users className="meta-icon" />
                          {notification.audience}
                        </span>
                        <span className="meta-item">
                          <Calendar className="meta-icon" />
                          {notification.time}
                        </span>
                        <span className="meta-item">Expires: {notification.expires}</span>
                      </div>
                      <p className="announcement-author">By {notification.author}</p>
                    </div>
                  </div>
                  <div className="announcement-actions">
                    <span className={`status-badge ${notification.type}`}>
                      {notification.type}
                    </span>
                    <button 
                      onClick={() => removeNotification(notification.id)}
                      className="remove-btn"
                    >
                      <X className="icon-small" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* System Overview Section */}
          <div className="system-overview">
            <h2 className="section-title">System Overview</h2>
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-content">
                  <div className="stat-info">
                    <p className="stat-label">Total Students</p>
                    <div className="stat-icon-wrapper">
                      <Users className="stat-icon-small blue" />
                    </div>
                  </div>
                  <div className="stat-main">
                    <p className="stat-value">12,847</p>
                    <p className="stat-change positive">↗ 8.2% from last semester</p>
                  </div>
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-content">
                  <div className="stat-info">
                    <p className="stat-label">Active Faculty</p>
                    <div className="stat-icon-wrapper">
                      <GraduationCap className="stat-icon-small green" />
                    </div>
                  </div>
                  <div className="stat-main">
                    <p className="stat-value">324</p>
                    <p className="stat-change positive">↗ 2.1% from last month</p>
                  </div>
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-content">
                  <div className="stat-info">
                    <p className="stat-label">Courses Offered</p>
                    <div className="stat-icon-wrapper">
                      <BookOpen className="stat-icon-small blue" />
                    </div>
                  </div>
                  <div className="stat-main">
                    <p className="stat-value">486</p>
                    <p className="stat-change neutral">— No change this semester</p>
                  </div>
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-content">
                  <div className="stat-info">
                    <p className="stat-label">Pass Rate</p>
                    <div className="stat-icon-wrapper">
                      <BarChart3 className="stat-icon-small blue" />
                    </div>
                  </div>
                  <div className="stat-main">
                    <p className="stat-value">94.2%</p>
                    <p className="stat-change positive">↗ 1.8% from last year</p>
                  </div>
                </div>
              </div>
              
              <div className="stat-card live-card">
                <div className="stat-content">
                  <div className="stat-info">
                    <p className="stat-label">Active Users</p>
                    <div className="live-indicator">
                      <div className="live-dot"></div>
                      <span className="live-text">LIVE</span>
                    </div>
                  </div>
                  <div className="stat-main">
                    <p className="stat-value">1,220</p>
                    <p className="stat-change neutral">Currently online</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Analytics & Performance Section */}
          <div className="analytics-section">
            <h2 className="section-title">Analytics & Performance</h2>
            <div className="analytics-grid">
              {/* Resource Utilization */}
              <div className="analytics-card">
                <h3 className="analytics-card-title">Resource Utilization</h3>
                <div className="pie-chart-container">
                  <div className="pie-chart">
                    <div className="pie-segment classrooms" style={{transform: 'rotate(0deg)'}}>
                      <div className="pie-slice" style={{transform: 'rotate(245deg)'}}></div>
                    </div>
                    <div className="pie-segment labs" style={{transform: 'rotate(245deg)'}}>
                      <div className="pie-slice" style={{transform: 'rotate(86deg)'}}></div>
                    </div>
                    <div className="pie-segment library" style={{transform: 'rotate(331deg)'}}>
                      <div className="pie-slice" style={{transform: 'rotate(29deg)'}}></div>
                    </div>
                    <div className="pie-center"></div>
                  </div>
                  <div className="pie-labels">
                    <div className="pie-label">
                      <span className="color-dot classrooms-dot"></span>
                      <span>Classrooms: 68%</span>
                    </div>
                    <div className="pie-label">
                      <span className="color-dot labs-dot"></span>
                      <span>Labs: 24%</span>
                    </div>
                    <div className="pie-label">
                      <span className="color-dot library-dot"></span>
                      <span>Library: 8%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Grade Distribution */}
              <div className="analytics-card">
                <h3 className="analytics-card-title">Grade Distribution</h3>
                <div className="bar-chart">
                  <div className="bar-container">
                    <div className="bar" style={{height: '60%'}}>
                      <div className="bar-fill"></div>
                    </div>
                    <div className="bar-label">A</div>
                  </div>
                  <div className="bar-container">
                    <div className="bar" style={{height: '85%'}}>
                      <div className="bar-fill"></div>
                    </div>
                    <div className="bar-label">B</div>
                  </div>
                  <div className="bar-container">
                    <div className="bar" style={{height: '70%'}}>
                      <div className="bar-fill"></div>
                    </div>
                    <div className="bar-label">C</div>
                  </div>
                  <div className="bar-container">
                    <div className="bar" style={{height: '40%'}}>
                      <div className="bar-fill"></div>
                    </div>
                    <div className="bar-label">D</div>
                  </div>
                  <div className="bar-container">
                    <div className="bar" style={{height: '25%'}}>
                      <div className="bar-fill"></div>
                    </div>
                    <div className="bar-label">F</div>
                  </div>
                </div>
                <div className="chart-y-axis">
                  <span>6000</span>
                  <span>4500</span>
                  <span>3000</span>
                  <span>1500</span>
                  <span>0</span>
                </div>
              </div>

              {/* Faculty Performance */}
              <div className="analytics-card">
                <h3 className="analytics-card-title">Faculty Performance</h3>
                <div className="performance-metrics">
                  <div className="metric-row">
                    <span className="metric-label">Research</span>
                    <div className="metric-bar">
                      <div className="metric-fill" style={{width: '85%'}}></div>
                    </div>
                  </div>
                  <div className="metric-row">
                    <span className="metric-label">Student Satisfaction</span>
                    <div className="metric-bar">
                      <div className="metric-fill" style={{width: '92%'}}></div>
                    </div>
                  </div>
                  <div className="metric-row">
                    <span className="metric-label">Innovation</span>
                    <div className="metric-bar">
                      <div className="metric-fill" style={{width: '78%'}}></div>
                    </div>
                  </div>
                  <div className="metric-row">
                    <span className="metric-label">Pass Rate</span>
                    <div className="metric-bar">
                      <div className="metric-fill" style={{width: '94%'}}></div>
                    </div>
                  </div>
                  <div className="metric-row">
                    <span className="metric-label">Grading Speed</span>
                    <div className="metric-bar">
                      <div className="metric-fill" style={{width: '88%'}}></div>
                    </div>
                  </div>
                  <div className="metric-row">
                    <span className="metric-label">Feedback Score</span>
                    <div className="metric-bar">
                      <div className="metric-fill" style={{width: '90%'}}></div>
                    </div>
                  </div>
                </div>
                <div className="performance-scale">
                  <span>0</span>
                  <span>2</span>
                  <span>5</span>
                </div>
              </div>
            </div>
          </div>
           {/* Department Analytics Section */}
          <div className="department-analytics">
          <div className="department-grid">
              {/* Dropout Risk by Department */}
              <div className="department-card">
                <h3 className="department-card-title">Dropout Risk by Department</h3>
                <div className="dropout-risk-list">
                  <div className="risk-item">
                    <div className="risk-info">
                      <span className="department-name">Computer Science</span>
                      <span className="student-count">1247 students</span>
                    </div>
                    <div className="risk-indicator">
                      <span className="risk-percentage low">15%</span>
                      <span className="risk-label low">Low Risk</span>
                    </div>
                  </div>
                  
                  <div className="risk-item">
                    <div className="risk-info">
                      <span className="department-name">Engineering</span>
                      <span className="student-count">2134 students</span>
                    </div>
                    <div className="risk-indicator">
                      <span className="risk-percentage medium">23%</span>
                      <span className="risk-label medium">Medium Risk</span>
                    </div>
                  </div>
                  
                  <div className="risk-item">
                    <div className="risk-info">
                      <span className="department-name">Business</span>
                      <span className="student-count">892 students</span>
                    </div>
                    <div className="risk-indicator">
                      <span className="risk-percentage low">8%</span>
                      <span className="risk-label low">Low Risk</span>
                    </div>
                  </div>
                  
                  <div className="risk-item">
                    <div className="risk-info">
                      <span className="department-name">Physics</span>
                      <span className="student-count">674 students</span>
                    </div>
                    <div className="risk-indicator">
                      <span className="risk-percentage high">35%</span>
                      <span className="risk-label high">High Risk</span>
                    </div>
                  </div>
                  
                  <div className="risk-item">
                    <div className="risk-info">
                      <span className="department-name">Mathematics</span>
                      <span className="student-count">456 students</span>
                    </div>
                    <div className="risk-indicator">
                      <span className="risk-percentage low">18%</span>
                      <span className="risk-label low">Low Risk</span>
                    </div>
                  </div>
                  
                  <div className="risk-item">
                    <div className="risk-info">
                      <span className="department-name">Literature</span>
                      <span className="student-count">334 students</span>
                    </div>
                    <div className="risk-indicator">
                      <span className="risk-percentage low">12%</span>
                      <span className="risk-label low">Low Risk</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Pass Rates by Subject */}
              <div className="department-card">
                <h3 className="department-card-title">Pass Rates by Subject</h3>
                <div className="pass-rates-list">
                  <div className="pass-rate-item">
                    <div className="subject-info">
                      <span className="subject-name">Mathematics</span>
                      <span className="pass-percentage">87%</span>
                    </div>
                    <div className="pass-rate-bar">
                      <div className="pass-rate-fill" style={{width: '87%'}}></div>
                    </div>
                  </div>
                  
                  <div className="pass-rate-item">
                    <div className="subject-info">
                      <span className="subject-name">Physics</span>
                      <span className="pass-percentage">79%</span>
                    </div>
                    <div className="pass-rate-bar">
                      <div className="pass-rate-fill" style={{width: '79%'}}></div>
                    </div>
                  </div>
                  
                  <div className="pass-rate-item">
                    <div className="subject-info">
                      <span className="subject-name">Chemistry</span>
                      <span className="pass-percentage">91%</span>
                    </div>
                    <div className="pass-rate-bar">
                      <div className="pass-rate-fill" style={{width: '91%'}}></div>
                    </div>
                  </div>
                  
                  <div className="pass-rate-item">
                    <div className="subject-info">
                      <span className="subject-name">Computer Science</span>
                      <span className="pass-percentage">94%</span>
                    </div>
                    <div className="pass-rate-bar">
                      <div className="pass-rate-fill" style={{width: '94%'}}></div>
                    </div>
                  </div>
                  
                  <div className="pass-rate-item">
                    <div className="subject-info">
                      <span className="subject-name">English</span>
                      <span className="pass-percentage">96%</span>
                    </div>
                    <div className="pass-rate-bar">
                      <div className="pass-rate-fill" style={{width: '96%'}}></div>
                    </div>
                  </div>
                  
                  <div className="pass-rate-item">
                    <div className="subject-info">
                      <span className="subject-name">History</span>
                      <span className="pass-percentage">89%</span>
                    </div>
                    <div className="pass-rate-bar">
                      <div className="pass-rate-fill" style={{width: '89%'}}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>
            <div className="advanced-analytics">
            <h2 className="section-title"></h2>
            
            {/* Course Demand Forecast */}
            <div className="forecast-section">
              <div className="forecast-card">
                <h3 className="forecast-card-title">Course Demand Forecast</h3>
                <div className="line-chart-container">
                  <div className="chart-legend">
                    <div className="legend-item">
                      <span className="legend-dot blue"></span>
                      <span>Computer Science</span>
                    </div>
                    <div className="legend-item">
                      <span className="legend-dot green"></span>
                      <span>Engineering</span>
                    </div>
                    <div className="legend-item">
                      <span className="legend-dot yellow"></span>
                      <span>Business</span>
                    </div>
                    <div className="legend-item">
                      <span className="legend-dot orange"></span>
                      <span>Mathematics</span>
                    </div>
                  </div>
                  <div className="line-chart">
                    <div className="chart-y-axis-forecast">
                      <span>400</span>
                      <span>300</span>
                      <span>200</span>
                      <span>100</span>
                      <span>0</span>
                    </div>
                    <div className="chart-area">
                      <svg className="line-chart-svg" viewBox="0 0 400 200">
                        {/* Grid lines */}
                        <defs>
                          <pattern id="grid" width="66.67" height="50" patternUnits="userSpaceOnUse">
                            <path d="M 66.67 0 L 0 0 0 50" fill="none" stroke="#e5e7eb" strokeWidth="1"/>
                          </pattern>
                        </defs>
                        <rect width="100%" height="100%" fill="url(#grid)" />
                        
                        {/* Computer Science Line (Blue) */}
                        <polyline
                          fill="none"
                          stroke="#3b82f6"
                          strokeWidth="2"
                          points="0,150 66.67,140 133.33,125 200,110 266.67,95 333.33,85 400,75"
                        />
                        <circle cx="0" cy="150" r="3" fill="#3b82f6" />
                        <circle cx="66.67" cy="140" r="3" fill="#3b82f6" />
                        <circle cx="133.33" cy="125" r="3" fill="#3b82f6" />
                        <circle cx="200" cy="110" r="3" fill="#3b82f6" />
                        <circle cx="266.67" cy="95" r="3" fill="#3b82f6" />
                        <circle cx="333.33" cy="85" r="3" fill="#3b82f6" />
                        <circle cx="400" cy="75" r="3" fill="#3b82f6" />
                        
                        {/* Engineering Line (Green) */}
                        <polyline
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="2"
                          points="0,175 66.67,170 133.33,165 200,160 266.67,155 333.33,150 400,145"
                        />
                        <circle cx="0" cy="175" r="3" fill="#10b981" />
                        <circle cx="66.67" cy="170" r="3" fill="#10b981" />
                        <circle cx="133.33" cy="165" r="3" fill="#10b981" />
                        <circle cx="200" cy="160" r="3" fill="#10b981" />
                        <circle cx="266.67" cy="155" r="3" fill="#10b981" />
                        <circle cx="333.33" cy="150" r="3" fill="#10b981" />
                        <circle cx="400" cy="145" r="3" fill="#10b981" />
                        
                        {/* Business Line (Yellow) */}
                        <polyline
                          fill="none"
                          stroke="#eab308"
                          strokeWidth="2"
                          points="0,185 66.67,180 133.33,175 200,170 266.67,165 333.33,160 400,155"
                        />
                        <circle cx="0" cy="185" r="3" fill="#eab308" />
                        <circle cx="66.67" cy="180" r="3" fill="#eab308" />
                        <circle cx="133.33" cy="175" r="3" fill="#eab308" />
                        <circle cx="200" cy="170" r="3" fill="#eab308" />
                        <circle cx="266.67" cy="165" r="3" fill="#eab308" />
                        <circle cx="333.33" cy="160" r="3" fill="#eab308" />
                        <circle cx="400" cy="155" r="3" fill="#eab308" />
                        
                        {/* Mathematics Line (Orange) */}
                        <polyline
                          fill="none"
                          stroke="#f97316"
                          strokeWidth="2"
                          points="0,190 66.67,188 133.33,185 200,182 266.67,180 333.33,175 400,170"
                        />
                        <circle cx="0" cy="190" r="3" fill="#f97316" />
                        <circle cx="66.67" cy="188" r="3" fill="#f97316" />
                        <circle cx="133.33" cy="185" r="3" fill="#f97316" />
                        <circle cx="200" cy="182" r="3" fill="#f97316" />
                        <circle cx="266.67" cy="180" r="3" fill="#f97316" />
                        <circle cx="333.33" cy="175" r="3" fill="#f97316" />
                        <circle cx="400" cy="170" r="3" fill="#f97316" />
                      </svg>
                      <div className="chart-x-axis">
                        <span>Fall 22</span>
                        <span>Spring 23</span>
                        <span>Fall 23</span>
                        <span>Spring 24</span>
                        <span>Fall 24</span>
                        <span>Spring 25</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Benchmarking & Student Engagement */}
            <div className="benchmarking-engagement-grid">
              {/* Performance Benchmarking */}
              <div className="benchmarking-card">
                <h3 className="benchmarking-card-title">Performance Benchmarking</h3>
                <div className="horizontal-bar-chart">
                  <div className="benchmark-item">
                    <div className="benchmark-label">Pass Rate</div>
                    <div className="benchmark-bar-container">
                      <div className="benchmark-bar">
                        <div className="benchmark-fill" style={{width: '94%'}}></div>
                      </div>
                      <span className="benchmark-value">0.94</span>
                    </div>
                  </div>
                  
                  <div className="benchmark-item">
                    <div className="benchmark-label">Student Satisfaction</div>
                    <div className="benchmark-bar-container">
                      <div className="benchmark-bar">
                        <div className="benchmark-fill" style={{width: '88%'}}></div>
                      </div>
                      <span className="benchmark-value">0.88</span>
                    </div>
                  </div>
                  
                  <div className="benchmark-item">
                    <div className="benchmark-label">Faculty Ratio</div>
                    <div className="benchmark-bar-container">
                      <div className="benchmark-bar">
                        <div className="benchmark-fill" style={{width: '75%'}}></div>
                      </div>
                      <span className="benchmark-value">0.75</span>
                    </div>
                  </div>
                  
                  <div className="benchmark-item">
                    <div className="benchmark-label">Research Output</div>
                    <div className="benchmark-bar-container">
                      <div className="benchmark-bar">
                        <div className="benchmark-fill" style={{width: '82%'}}></div>
                      </div>
                      <span className="benchmark-value">0.82</span>
                    </div>
                  </div>
                  
                  <div className="benchmark-item">
                    <div className="benchmark-label">Employment Rate</div>
                    <div className="benchmark-bar-container">
                      <div className="benchmark-bar">
                        <div className="benchmark-fill" style={{width: '91%'}}></div>
                      </div>
                      <span className="benchmark-value">0.91</span>
                    </div>
                  </div>
                  
                  <div className="benchmark-scale">
                    <span>0</span>
                    <span>0.25</span>
                    <span>0.5</span>
                    <span>0.75</span>
                    <span>1</span>
                  </div>
                </div>
              </div>

              {/* Student Engagement Trends */}
              <div className="engagement-card">
                <h3 className="engagement-card-title">Student Engagement Trends</h3>
                <div className="engagement-chart-container">
                  <div className="engagement-legend">
                    <div className="legend-item">
                      <span className="legend-dot blue"></span>
                      <span>Attendance</span>
                    </div>
                    <div className="legend-item">
                      <span className="legend-dot green"></span>
                      <span>Assignment Submission</span>
                    </div>
                    <div className="legend-item">
                      <span className="legend-dot yellow"></span>
                      <span>Discussion Participation</span>
                    </div>
                  </div>
                  <div className="engagement-chart">
                    <div className="engagement-y-axis">
                      <span>100</span>
                      <span>75</span>
                      <span>50</span>
                      <span>25</span>
                      <span>0</span>
                    </div>
                    <div className="engagement-chart-area">
                      <svg className="engagement-chart-svg" viewBox="0 0 300 150">
                        {/* Grid lines */}
                        <defs>
                          <pattern id="engagement-grid" width="50" height="37.5" patternUnits="userSpaceOnUse">
                            <path d="M 50 0 L 0 0 0 37.5" fill="none" stroke="#e5e7eb" strokeWidth="1"/>
                          </pattern>
                        </defs>
                        <rect width="100%" height="100%" fill="url(#engagement-grid)" />
                        
                        {/* Attendance Line (Blue) */}
                        <polyline
                          fill="none"
                          stroke="#3b82f6"
                          strokeWidth="2"
                          points="0,30 50,27 100,25 150,24 200,22 250,20 300,18"
                        />
                        <circle cx="0" cy="30" r="2" fill="#3b82f6" />
                        <circle cx="50" cy="27" r="2" fill="#3b82f6" />
                        <circle cx="100" cy="25" r="2" fill="#3b82f6" />
                        <circle cx="150" cy="24" r="2" fill="#3b82f6" />
                        <circle cx="200" cy="22" r="2" fill="#3b82f6" />
                        <circle cx="250" cy="20" r="2" fill="#3b82f6" />
                        <circle cx="300" cy="18" r="2" fill="#3b82f6" />
                        
                        {/* Assignment Submission Line (Green) */}
                        <polyline
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="2"
                          points="0,75 50,65 100,60 150,55 200,50 250,45 300,18"
                        />
                        <circle cx="0" cy="75" r="2" fill="#10b981" />
                        <circle cx="50" cy="65" r="2" fill="#10b981" />
                        <circle cx="100" cy="60" r="2" fill="#10b981" />
                        <circle cx="150" cy="55" r="2" fill="#10b981" />
                        <circle cx="200" cy="50" r="2" fill="#10b981" />
                        <circle cx="250" cy="45" r="2" fill="#10b981" />
                        <circle cx="300" cy="18" r="2" fill="#10b981" />
                        
                        {/* Discussion Participation Line (Yellow) */}
                        <polyline
                          fill="none"
                          stroke="#eab308"
                          strokeWidth="2"
                          points="0,112 50,105 100,105 150,100 200,85 250,75 300,93"
                        />
                        <circle cx="0" cy="112" r="2" fill="#eab308" />
                        <circle cx="50" cy="105" r="2" fill="#eab308" />
                        <circle cx="100" cy="105" r="2" fill="#eab308" />
                        <circle cx="150" cy="100" r="2" fill="#eab308" />
                        <circle cx="200" cy="85" r="2" fill="#eab308" />
                        <circle cx="250" cy="75" r="2" fill="#eab308" />
                        <circle cx="300" cy="93" r="2" fill="#eab308" />
                      </svg>
                      <div className="engagement-x-axis">
                        <span>Jan</span>
                        <span>Feb</span>
                        <span>Mar</span>
                        <span>Apr</span>
                        <span>May</span>
                        <span>Jun</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
            <div className="gap-analysis-section">
            <div className="gap-analysis-header">
              <h2 className="section-title">Gap Analysis & Predictive Insights</h2>
            </div>
            
            <div className="priority-opportunities">
              <div className="priority-header">
                <h3 className="priority-title">Priority Improvement Opportunities</h3>
                <span className="opportunities-count">5 opportunities identified</span>
              </div>
              
              <div className="opportunities-grid">
                <div className="opportunity-card high-impact">
                  <div className="opportunity-header">
                    <div className="opportunity-number">#1</div>
                    <div className="impact-badge high">high impact</div>
                  </div>
                  <h4 className="opportunity-title">Reduce Physics Department Dropout Rate</h4>
                  <p className="opportunity-description">Implement early intervention system for at-risk students</p>
                  
                  <div className="opportunity-details">
                    <div className="detail-row">
                      <span className="detail-label">Category:</span>
                      <span className="detail-value">Academic Performance</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Timeline:</span>
                      <span className="detail-value">3 months</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Effort:</span>
                      <span className="detail-value">medium</span>
                    </div>
                  </div>
                  
                  <div className="expected-impact">
                    <span className="impact-label">Expected Impact:</span>
                    <span className="impact-value positive">15% reduction in dropout rate</span>
                  </div>
                  
                  <button className="action-plan-btn">
                    Create Action Plan →
                  </button>
                </div>

                <div className="opportunity-card medium-impact">
                  <div className="opportunity-header">
                    <div className="opportunity-number">#2</div>
                    <div className="impact-badge medium">medium impact</div>
                  </div>
                  <h4 className="opportunity-title">Enhance Faculty Digital Skills</h4>
                  <p className="opportunity-description">Provide comprehensive LMS training program</p>
                  
                  <div className="opportunity-details">
                    <div className="detail-row">
                      <span className="detail-label">Category:</span>
                      <span className="detail-value">Technology Adoption</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Timeline:</span>
                      <span className="detail-value">6 weeks</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Effort:</span>
                      <span className="detail-value">low</span>
                    </div>
                  </div>
                  
                  <div className="expected-impact">
                    <span className="impact-label">Expected Impact:</span>
                    <span className="impact-value positive">25% increase in platform usage</span>
                  </div>
                  
                  <button className="action-plan-btn">
                    Create Action Plan →
                  </button>
                </div>

                <div className="opportunity-card high-impact">
                  <div className="opportunity-header">
                    <div className="opportunity-number">#3</div>
                    <div className="impact-badge high">high impact</div>
                  </div>
                  <h4 className="opportunity-title">Optimize Course Scheduling</h4>
                  <p className="opportunity-description">Use AI to reduce conflicts and improve resource utilization</p>
                  
                  <div className="opportunity-details">
                    <div className="detail-row">
                      <span className="detail-label">Category:</span>
                      <span className="detail-value">Operations</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Timeline:</span>
                      <span className="detail-value">4 months</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Effort:</span>
                      <span className="detail-value effort-high">high</span>
                    </div>
                  </div>
                  
                  <div className="expected-impact">
                    <span className="impact-label">Expected Impact:</span>
                    <span className="impact-value positive">30% better resource efficiency</span>
                  </div>
                  
                  <button className="action-plan-btn">
                    Create Action Plan →
                  </button>
                </div>

                <div className="opportunity-card medium-impact">
                  <div className="opportunity-header">
                    <div className="opportunity-number">#4</div>
                    <div className="impact-badge medium">medium impact</div>
                  </div>
                  <h4 className="opportunity-title">Expand Popular Elective Courses</h4>
                  <p className="opportunity-description">Increase sections for high-demand AI/ML courses</p>
                  
                  <div className="opportunity-details">
                    <div className="detail-row">
                      <span className="detail-label">Category:</span>
                      <span className="detail-value">Curriculum</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Timeline:</span>
                      <span className="detail-value">2 months</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Effort:</span>
                      <span className="detail-value">medium</span>
                    </div>
                  </div>
                  
                  <div className="expected-impact">
                    <span className="impact-label">Expected Impact:</span>
                    <span className="impact-value positive">40% more student satisfaction</span>
                  </div>
                  
                  <button className="action-plan-btn">
                    Create Action Plan →
                  </button>
                </div>

                <div className="opportunity-card medium-impact">
                  <div className="opportunity-header">
                    <div className="opportunity-number">#5</div>
                    <div className="impact-badge medium">medium impact</div>
                  </div>
                  <h4 className="opportunity-title">Student Engagement Initiative</h4>
                  <p className="opportunity-description">Launch peer mentoring and study group programs</p>
                  
                  <div className="opportunity-details">
                    <div className="detail-row">
                      <span className="detail-label">Category:</span>
                      <span className="detail-value">Student Success</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Timeline:</span>
                      <span className="detail-value">8 weeks</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Effort:</span>
                      <span className="detail-value">low</span>
                    </div>
                  </div>
                  
                  <div className="expected-impact">
                    <span className="impact-label">Expected Impact:</span>
                    <span className="impact-value positive">20% improvement in retention</span>
                  </div>
                  
                  <button className="action-plan-btn">
                    Create Action Plan →
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Student & Faculty Management Section */}
          <div className="management-section">
            <h2 className="section-title">Student & Faculty Management</h2>
            
            <div className="at-risk-students">
              <div className="at-risk-header">
                <div className="at-risk-title">
                  <AlertTriangle className="warning-icon" />
                  <h3>At-Risk Students</h3>
                </div>
                <button className="export-btn">
                  Export
                </button>
              </div>
              
              <div className="students-table">
                <div className="table-header">
                  <div className="header-cell">Student</div>
                  <div className="header-cell">Department</div>
                  <div className="header-cell">GPA</div>
                  <div className="header-cell">Attendance</div>
                  <div className="header-cell">Risk Level</div>
                  <div className="header-cell">Issues</div>
                  <div className="header-cell">Actions</div>
                </div>
                
                <div className="table-row">
                  <div className="student-info">
                    <div className="student-name">Alex Chen</div>
                    <div className="student-id">STU001</div>
                  </div>
                  <div className="department">Computer Science</div>
                  <div className="gpa">2.1</div>
                  <div className="attendance poor">68%</div>
                  <div className="risk-level high">high</div>
                  <div className="issues">
                    <span className="issue-tag">Low GPA</span>
                    <span className="issue-tag">Poor Attendance</span>
                  </div>
                  <div className="action-buttons">
                    <button className="contact-btn">✉</button>
                    <button className="call-btn">📞</button>
                  </div>
                </div>
                
                <div className="table-row">
                  <div className="student-info">
                    <div className="student-name">Maria Rodriguez</div>
                    <div className="student-id">STU002</div>
                  </div>
                  <div className="department">Mathematics</div>
                  <div className="gpa">2.5</div>
                  <div className="attendance">72%</div>
                  <div className="risk-level medium">medium</div>
                  <div className="issues">
                    <span className="issue-tag">Failing Calculus II</span>
                  </div>
                  <div className="action-buttons">
                    <button className="contact-btn">✉</button>
                    <button className="call-btn">📞</button>
                  </div>
                </div>
                
                <div className="table-row">
                  <div className="student-info">
                    <div className="student-name">James Wilson</div>
                    <div className="student-id">STU003</div>
                  </div>
                  <div className="department">Physics</div>
                  <div className="gpa">2.3</div>
                  <div className="attendance poor">65%</div>
                  <div className="risk-level high">high</div>
                  <div className="issues">
                    <span className="issue-tag">Low GPA</span>
                    <span className="issue-tag">Poor Attendance</span>
                    <span className="issue-tag">Financial Issues</span>
                  </div>
                  <div className="action-buttons">
                    <button className="contact-btn">✉</button>
                    <button className="call-btn">📞</button>
                  </div>
                </div>
                
                <div className="table-row">
                  <div className="student-info">
                    <div className="student-name">Sarah Johnson</div>
                    <div className="student-id">STU004</div>
                  </div>
                  <div className="department">Biology</div>
                  <div className="gpa">2.7</div>
                  <div className="attendance">78%</div>
                  <div className="risk-level medium">medium</div>
                  <div className="issues">
                    <span className="issue-tag">Struggling with Organic Chemistry</span>
                  </div>
                  <div className="action-buttons">
                    <button className="contact-btn">✉</button>
                    <button className="call-btn">📞</button>
                  </div>
                </div>
              </div>
            </div>

            <div className="faculty-course-grid">
              <div className="faculty-workload">
                <h3 className="card-title">Faculty Workload</h3>
                <div className="workload-table">
                  <div className="workload-header">
                    <div>Faculty</div>
                    <div>Courses</div>
                    <div>Students</div>
                    <div>Load</div>
                  </div>
                  
                  <div className="workload-row">
                    <div className="faculty-info">
                      <div className="faculty-name">Dr. Emily Thompson</div>
                      <div className="faculty-dept">Computer Science</div>
                    </div>
                    <div>3</div>
                    <div>145</div>
                    <div className="load-badge high">high</div>
                  </div>
                  
                  <div className="workload-row">
                    <div className="faculty-info">
                      <div className="faculty-name">Prof. Michael Davis</div>
                      <div className="faculty-dept">Mathematics</div>
                    </div>
                    <div>2</div>
                    <div>89</div>
                    <div className="load-badge normal">normal</div>
                  </div>
                  
                  <div className="workload-row">
                    <div className="faculty-info">
                      <div className="faculty-name">Dr. Lisa Park</div>
                      <div className="faculty-dept">Physics</div>
                    </div>
                    <div>4</div>
                    <div>167</div>
                    <div className="load-badge high">high</div>
                  </div>
                </div>
              </div>

              <div className="course-enrollment">
                <h3 className="card-title">Course Enrollment</h3>
                <div className="enrollment-table">
                  <div className="enrollment-header">
                    <div>Course</div>
                    <div>Enrolled</div>
                    <div>Waitlist</div>
                    <div>Status</div>
                  </div>
                  
                  <div className="enrollment-row">
                    <div className="course-info">
                      <div className="course-code">CS101</div>
                      <div className="course-name">Introduction to Programming</div>
                    </div>
                    <div>125/130</div>
                    <div>15</div>
                    <div className="status-badge full">full</div>
                  </div>
                  
                  <div className="enrollment-row">
                    <div className="course-info">
                      <div className="course-code">MATH201</div>
                      <div className="course-name">Calculus II</div>
                    </div>
                    <div>89/120</div>
                    <div>0</div>
                    <div className="status-badge open">open</div>
                  </div>
                  
                  <div className="enrollment-row">
                    <div className="course-info">
                      <div className="course-code">PHYS301</div>
                      <div className="course-name">Quantum Mechanics</div>
                    </div>
                    <div>45/50</div>
                    <div>0</div>
                    <div className="status-badge open">open</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Reports & Compliance Section */}
          <div className="reports-section">
            <h2 className="section-title">Reports & Compliance</h2>
            
            <div className="reports-grid">
              <div className="report-templates">
                <div className="reports-header">
                  <div className="reports-title-section">
                    <FileText className="reports-icon" />
                    <h3>Report Templates</h3>
                  </div>
                  <select className="category-filter">
                    <option>All Categories</option>
                    <option>Academic</option>
                    <option>Financial</option>
                    <option>Administrative</option>
                  </select>
                </div>
                
                <div className="report-list">
                  <div className="report-item">
                    <div className="report-icon-wrapper">
                      <Users className="report-icon blue" />
                    </div>
                    <div className="report-content">
                      <h4 className="report-title">Student Performance Report</h4>
                      <p className="report-description">Comprehensive analysis of student academic performance</p>
                      <div className="report-meta">
                        <span>Last generated: 2024-01-15 • 5 recipients</span>
                      </div>
                    </div>
                    <div className="report-actions">
                      <span className="frequency-badge">Monthly</span>
                      <button className="generate-btn">Generate</button>
                    </div>
                  </div>
                  
                  <div className="report-item">
                    <div className="report-icon-wrapper">
                      <span className="dollar-icon">$</span>
                    </div>
                    <div className="report-content">
                      <h4 className="report-title">Financial Summary Report</h4>
                      <p className="report-description">Revenue, expenses, and budget analysis</p>
                      <div className="report-meta">
                        <span>Last generated: 2024-01-01 • 3 recipients</span>
                      </div>
                    </div>
                    <div className="report-actions">
                      <span className="frequency-badge">Quarterly</span>
                      <button className="generate-btn">Generate</button>
                    </div>
                  </div>
                  
                  <div className="report-item">
                    <div className="report-icon-wrapper">
                      <BarChart3 className="report-icon green" />
                    </div>
                    <div className="report-content">
                      <h4 className="report-title">Faculty Workload Analysis</h4>
                      <p className="report-description">Teaching assignments and performance metrics</p>
                      <div className="report-meta">
                        <span>Last generated: 2024-01-10 • 7 recipients</span>
                      </div>
                    </div>
                    <div className="report-actions">
                      <span className="frequency-badge">Bi-weekly</span>
                      <button className="generate-btn">Generate</button>
                    </div>
                  </div>
                  
                  <div className="report-item">
                    <div className="report-icon-wrapper">
                      <BookOpen className="report-icon orange" />
                    </div>
                    <div className="report-content">
                      <h4 className="report-title">Course Enrollment Trends</h4>
                      <p className="report-description">Student registration patterns and demand forecasting</p>
                      <div className="report-meta">
                        <span>Last generated: 2024-01-16 • 4 recipients</span>
                      </div>
                    </div>
                    <div className="report-actions">
                      <span className="frequency-badge">Weekly</span>
                      <button className="generate-btn">Generate</button>
                    </div>
                  </div>
                  
                  <div className="report-item">
                    <div className="report-icon-wrapper">
                      <Settings className="report-icon purple" />
                    </div>
                    <div className="report-content">
                      <h4 className="report-title">Resource Utilization Report</h4>
                      <p className="report-description">Facilities usage and optimization recommendations</p>
                      <div className="report-meta">
                        <span>Last generated: 2024-01-12 • 6 recipients</span>
                      </div>
                    </div>
                    <div className="report-actions">
                      <span className="frequency-badge">Monthly</span>
                      <button className="generate-btn">Generate</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="scheduled-reports">
                <div className="scheduled-header">
                  <h3 className="scheduled-title">Scheduled Reports</h3>
                </div>
                
                <div className="scheduled-list">
                  <div className="scheduled-item">
                    <div className="scheduled-content">
                      <h4>Weekly Performance Summary</h4>
                      <div className="scheduled-meta">
                        <span>Next: 2024-01-22 09:00</span>
                        <span>Frequency: Weekly</span>
                      </div>
                    </div>
                    <div className="scheduled-status active">active</div>
                  </div>
                  
                  <div className="scheduled-item">
                    <div className="scheduled-content">
                      <h4>Monthly Financial Report</h4>
                      <div className="scheduled-meta">
                        <span>Next: 2024-02-01 08:00</span>
                        <span>Frequency: Monthly</span>
                      </div>
                    </div>
                    <div className="scheduled-status active">active</div>
                  </div>
                  
                  <div className="scheduled-item">
                    <div className="scheduled-content">
                      <h4>Semester Analytics Report</h4>
                      <div className="scheduled-meta">
                        <span>Next: 2024-01-30 10:00</span>
                        <span>Frequency: Semester</span>
                      </div>
                    </div>
                    <div className="scheduled-status paused">paused</div>
                  </div>
                </div>
                
                <div className="scheduled-actions">
                  <button className="schedule-new-btn">
                    📅 Schedule New Report
                  </button>
                  <button className="manage-recipients-btn">
                    ✉ Manage Recipients
                  </button>
                </div>
              </div>
            </div>
             </div>
            <div className="financial-summary">
              <div className="financial-header">
                <span className="dollar-icon-large">$</span>
                <h3>Financial Report Summary</h3>
              </div>
              
              <div className="financial-table-header">
                <div>Category</div>
                <div>Amount</div>
                <div>Change</div>
                <div>Type</div>
              </div>
           
         
          {/* Financial Summary Table Content */}
          <div className="financial-table-content">
            <div className="financial-row">
              <div className="financial-category">Tuition Revenue</div>
              <div className="financial-amount">$2,400,000</div>
              <div className="financial-change positive">+8.2%</div>
              <div className="financial-type income">income</div>
            </div>
            
            <div className="financial-row">
              <div className="financial-category">Government Grants</div>
              <div className="financial-amount">$800,000</div>
              <div className="financial-change positive">+12.5%</div>
              <div className="financial-type income">income</div>
            </div>
            
            <div className="financial-row">
              <div className="financial-category">Research Funding</div>
              <div className="financial-amount">$600,000</div>
              <div className="financial-change negative">-2.1%</div>
              <div className="financial-type income">income</div>
            </div>
            
            <div className="financial-row">
              <div className="financial-category">Faculty Salaries</div>
              <div className="financial-amount">$1,800,000</div>
              <div className="financial-change positive">+4.3%</div>
              <div className="financial-type expense">expense</div>
            </div>
            
            <div className="financial-row">
              <div className="financial-category">Infrastructure</div>
              <div className="financial-amount">$400,000</div>
              <div className="financial-change positive">+15.2%</div>
              <div className="financial-type expense">expense</div>
            </div>
            
            <div className="financial-row">
              <div className="financial-category">Technology Costs</div>
              <div className="financial-amount">$300,000</div>
              <div className="financial-change positive">+22.1%</div>
              <div className="financial-type expense">expense</div>
            </div>
            
            <div className="financial-row">
              <div className="financial-category">Administrative Costs</div>
              <div className="financial-amount">$250,000</div>
              <div className="financial-change negative">-1.8%</div>
              <div className="financial-type expense">expense</div>
            </div>
          </div>
          
          <div className="financial-footer">
            <div className="financial-updated">
              Updated: January 16, 2024 at 2:30 PM
            </div>
            <div className="financial-export-buttons">
              <button className="export-pdf-btn">
                📄 Export PDF
              </button>
              <button className="export-excel-btn">
                📊 Export Excel
              </button>
            </div>
          </div>
           </div>

          {/* Alerts & Monitoring Section */}
          <div className="alerts-monitoring-section">
            <h2 className="section-title">Alerts & Monitoring</h2>
            
            <div className="alerts-grid">
              {/* System Alerts */}
              <div className="system-alerts-card">
                <div className="alerts-card-header">
                  <div className="alerts-title-section">
                    <Bell className="alerts-icon" />
                    <h3>System Alerts</h3>
                  </div>
                  <span className="active-alerts-count">4 active</span>
                </div>
                
                <div className="alerts-list">
                  <div className="alert-item high-priority">
                    <div className="alert-icon-wrapper">
                      <AlertTriangle className="alert-item-icon warning" />
                    </div>
                    <div className="alert-content">
                      <h4 className="alert-item-title">High Dropout Risk Detected</h4>
                      <p className="alert-description">25% of Physics students are showing signs of academic distress</p>
                      <span className="alert-time">2 hours ago</span>
                    </div>
                    <div className="alert-actions">
                      <span className="alert-priority high">high</span>
                      <button className="alert-dismiss">
                        <X className="icon-small" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="alert-item low-priority">
                    <div className="alert-icon-wrapper">
                      <CheckCircle className="alert-item-icon success" />
                    </div>
                    <div className="alert-content">
                      <h4 className="alert-item-title">Fee Collection Target Met</h4>
                      <p className="alert-description">95% of semester fees collected - target exceeded</p>
                      <span className="alert-time">4 hours ago</span>
                    </div>
                    <div className="alert-actions">
                      <span className="alert-priority low">low</span>
                      <button className="alert-dismiss">
                        <X className="icon-small" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="alert-item medium-priority">
                    <div className="alert-icon-wrapper">
                      <Info className="alert-item-icon info" />
                    </div>
                    <div className="alert-content">
                      <h4 className="alert-item-title">New Course Registration Opens</h4>
                      <p className="alert-description">Summer 2024 course registration begins tomorrow</p>
                      <span className="alert-time">6 hours ago</span>
                    </div>
                    <div className="alert-actions">
                      <span className="alert-priority medium">medium</span>
                      <button className="alert-dismiss">
                        <X className="icon-small" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="alert-item high-priority">
                    <div className="alert-icon-wrapper">
                      <AlertTriangle className="alert-item-icon error" />
                    </div>
                    <div className="alert-content">
                      <h4 className="alert-item-title">Server Maintenance Required</h4>
                      <p className="alert-description">Database backup system needs immediate attention</p>
                      <span className="alert-time">8 hours ago</span>
                    </div>
                    <div className="alert-actions">
                      <span className="alert-priority high">high</span>
                      <button className="alert-dismiss">
                        <X className="icon-small" />
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="alert-footer-actions">
                  <button className="send-email-alert-btn">
                    ✉ Send Email Alert
                  </button>
                  <button className="send-sms-alert-btn">
                    📱 Send SMS Alert
                  </button>
                </div>
              </div>

              {/* Threshold Monitoring */}
              <div className="threshold-monitoring-card">
                <div className="threshold-header">
                  <h3>Threshold Monitoring</h3>
                </div>
                
                <div className="threshold-metrics">
                  <div className="threshold-metric">
                    <div className="metric-info">
                      <span className="metric-name">Library Capacity</span>
                      <span className="metric-status normal">normal</span>
                    </div>
                    <div className="metric-bar-container">
                      <div className="metric-progress-bar">
                        <div className="metric-fill normal" style={{width: '68%'}}></div>
                      </div>
                      <div className="metric-values">
                        <span className="current-value">342</span>
                        <span className="limit-value">400 limit</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="threshold-metric">
                    <div className="metric-info">
                      <span className="metric-name">Server Load</span>
                      <span className="metric-status warning">warning</span>
                    </div>
                    <div className="metric-bar-container">
                      <div className="metric-progress-bar">
                        <div className="metric-fill warning" style={{width: '78%'}}></div>
                      </div>
                      <div className="metric-values">
                        <span className="current-value">78</span>
                        <span className="limit-value">85 limit</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="threshold-metric">
                    <div className="metric-info">
                      <span className="metric-name">Failed Logins</span>
                      <span className="metric-status normal">normal</span>
                    </div>
                    <div className="metric-bar-container">
                      <div className="metric-progress-bar">
                        <div className="metric-fill normal" style={{width: '46%'}}></div>
                      </div>
                      <div className="metric-values">
                        <span className="current-value">23</span>
                        <span className="limit-value">50 limit</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="threshold-metric">
                    <div className="metric-info">
                      <span className="metric-name">Bandwidth Usage</span>
                      <span className="metric-status normal">normal</span>
                    </div>
                    <div className="metric-bar-container">
                      <div className="metric-progress-bar">
                        <div className="metric-fill normal" style={{width: '60%'}}></div>
                      </div>
                      <div className="metric-values">
                        <span className="current-value">1.2Gbps</span>
                        <span className="limit-value">2Gbps limit</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Fee Collection Progress & Compliance Status */}
            <div className="bottom-monitoring-grid">
              <div className="fee-collection-card">
                <div className="fee-collection-header">
                  <span className="dollar-icon-medium">$</span>
                  <h3>Fee Collection Progress</h3>
                </div>
                
                <div className="fee-collection-content">
                  <div className="fee-amount-display">
                    <span className="fee-amount">$2.4M</span>
                    <span className="fee-target">of $2.8M target</span>
                  </div>
                  
                  <div className="fee-progress-bar">
                    <div className="fee-progress-fill" style={{width: '85.7%'}}></div>
                  </div>
                  
                  <div className="fee-progress-details">
                    <span className="fee-percentage">85.7% collected</span>
                    <span className="fee-vs-target positive">+5.2% vs target</span>
                  </div>
                  
                  <button className="export-financial-btn">
                    📄 Export Financial Report
                  </button>
                </div>
              </div>

              <div className="compliance-status-card">
                <div className="compliance-header">
                  <h3>Compliance Status</h3>
                </div>
                
                <div className="compliance-list">
                  <div className="compliance-item">
                    <div className="compliance-icon-wrapper">
                      <CheckCircle className="compliance-icon success" />
                    </div>
                    <div className="compliance-content">
                      <h4 className="compliance-name">FERPA Compliance</h4>
                      <span className="compliance-date">Last checked: 2024-01-15</span>
                    </div>
                    <span className="compliance-badge compliant">compliant</span>
                  </div>
                  
                  <div className="compliance-item">
                    <div className="compliance-icon-wrapper">
                      <CheckCircle className="compliance-icon success" />
                    </div>
                    <div className="compliance-content">
                      <h4 className="compliance-name">GDPR Compliance</h4>
                      <span className="compliance-date">Last checked: 2024-01-14</span>
                    </div>
                    <span className="compliance-badge compliant">compliant</span>
                  </div>
                  
                  <div className="compliance-item">
                    <div className="compliance-icon-wrapper">
                      <AlertTriangle className="compliance-icon warning" />
                    </div>
                    <div className="compliance-content">
                      <h4 className="compliance-name">SOC 2 Audit</h4>
                      <span className="compliance-date">Last checked: 2024-01-10</span>
                    </div>
                    <span className="compliance-badge pending">pending</span>
                  </div>
                  
                  <div className="compliance-item">
                    <div className="compliance-icon-wrapper">
                      <CheckCircle className="compliance-icon success" />
                    </div>
                    <div className="compliance-content">
                      <h4 className="compliance-name">Data Backup Verification</h4>
                      <span className="compliance-date">Last checked: 2024-01-16</span>
                    </div>
                    <span className="compliance-badge compliant">compliant</span>
                  </div>
                  
                  <div className="compliance-item">
                    <div className="compliance-icon-wrapper">
                      <X className="compliance-icon error" />
                    </div>
                    <div className="compliance-content">
                      <h4 className="compliance-name">Security Assessment</h4>
                      <span className="compliance-date">Last checked: 2024-01-05</span>
                    </div>
                    <span className="compliance-badge non-compliant">non compliant</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default EduDashboard;