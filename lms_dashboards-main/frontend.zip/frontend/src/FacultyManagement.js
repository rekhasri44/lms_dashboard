import React, { useState } from 'react';
import { Mail, Phone, Clock, Download, Filter, UserPlus } from 'lucide-react';
import './FacultyManagement.css';
import { 
  Bell, 
  User, 
  BarChart3, 
  BookOpen, 
  Users, 
  GraduationCap, 
  FileText, 
  Settings,
  Info,
  X,
  CheckCircle,
  AlertTriangle,
  Calendar
} from 'lucide-react';
const FacultyManagement = () => {
  const [faculty] = useState([
    {
      id: 'FAC001',
      name: 'Dr. Emily Thompson',
      email: 'emily.thompson@university.edu',
      position: 'Professor',
      experience: '12 years exp.',
      department: 'Computer Science',
      courses: 3,
      students: 145,
      rating: 4.5,
      workload: 85,
      status: 'active'
    },
    {
      id: 'FAC002',
      name: 'Prof. Michael Davis',
      email: 'michael.davis@university.edu',
      position: 'Associate Professor',
      experience: '8 years exp.',
      department: 'Mathematics',
      courses: 2,
      students: 89,
      rating: 4.2,
      workload: 65,
      status: 'active'
    },
    {
      id: 'FAC003',
      name: 'Dr. Lisa Park',
      email: 'lisa.park@university.edu',
      position: 'Professor',
      experience: '15 years exp.',
      department: 'Physics',
      courses: 4,
      students: 167,
      rating: 4.7,
      workload: 95,
      status: 'active'
    },
    {
      id: 'FAC004',
      name: 'Prof. Robert Brown',
      email: 'robert.brown@university.edu',
      position: 'Assistant Professor',
      experience: '4 years exp.',
      department: 'Biology',
      courses: 2,
      students: 76,
      rating: 3.9,
      workload: 55,
      status: 'active'
    },
    {
      id: 'FAC005',
      name: 'Dr. Amanda Wilson',
      email: 'amanda.wilson@university.edu',
      position: 'Professor',
      experience: '18 years exp.',
      department: 'Chemistry',
      courses: 3,
      students: 112,
      rating: 4.4,
      workload: 0,
      status: 'sabbatical'
    }
  ]);

  return (
    <div className="faculty-management">
          <div className="sidebar">
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon">
              <GraduationCap className="icon-medium" />
            </div>

         
            
          
            <span className="logo-text">EduAdmin</span>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <div className="nav-section-title">
            Navigation
          </div>
          <div className="nav-links">
            <a href="/" className="nav-link active">
              <BarChart3 className="nav-icon" />
              Overview
            </a>
            <a href="/student" className="nav-link">
              <Users className="nav-icon" />
              Students
            </a>
            <a href="/faculty" className="nav-link">
              <GraduationCap className="nav-icon" />
              Faculty
            </a>
            <a href="/course" className="nav-link">
              <BookOpen className="nav-icon" />
              Courses
            </a>
            <a href="/analytics" className="nav-link">
                          <BarChart3 className="nav-icon" />
                          Analytics
                        </a>
                        <a href="/reports" className="nav-link">
                          <FileText className="nav-icon" />
                          Reports
                        </a>
                        <a href="/settings" className="nav-link">
                          <Settings className="nav-icon" />
                          Settings
                        </a>
          </div>
        </nav>
      </div>
      <div className='right'>
      <div className="fm-header">
        <h1>Faculty Management</h1>
        <div className="fm-header-actions">
          <span className="notification-dot"></span>
          <div className="user-avatar"></div>
        </div>
      </div>

      <div className="fm-stats">
        <div className="fm-stat-card">
          <div className="fm-stat-label">Total Faculty</div>
          <div className="fm-stat-value">324</div>
          <div className="fm-stat-change positive">↑ 2.1% from last semester</div>
        </div>
        <div className="fm-stat-card">
          <div className="fm-stat-label">New Hires</div>
          <div className="fm-stat-value">18</div>
          <div className="fm-stat-change positive">↑ 15.2% from last semester</div>
        </div>
        <div className="fm-stat-card">
          <div className="fm-stat-label">Avg Rating</div>
          <div className="fm-stat-value">4.2/5</div>
          <div className="fm-stat-change positive">↑ 3.1% from last semester</div>
        </div>
        <div className="fm-stat-card">
          <div className="fm-stat-label">Research Active</div>
          <div className="fm-stat-value">87%</div>
          <div className="fm-stat-change positive">↑ 1.8% from last semester</div>
        </div>
      </div>

      <div className="fm-directory">
        <div className="fm-directory-header">
          <h2>Faculty Directory</h2>
          <div className="fm-directory-actions">
            <button className="fm-btn fm-btn-secondary">
              <Filter size={16} /> Filter
            </button>
            <button className="fm-btn fm-btn-secondary">
              <Download size={16} /> Export
            </button>
            <button className="fm-btn fm-btn-primary">
              <UserPlus size={16} /> Add Faculty
            </button>
          </div>
        </div>

        <div className="fm-search">
          <input type="text" placeholder="Search faculty by name, department, or position..." />
        </div>

        <div className="fm-table">
          <div className="fm-table-header">
            <div>Faculty</div>
            <div>Position</div>
            <div>Department</div>
            <div>Courses</div>
            <div>Students</div>
            <div>Rating</div>
            <div>Workload</div>
            <div>Status</div>
            <div>Actions</div>
          </div>
          {faculty.map(f => (
            <div key={f.id} className="fm-table-row">
              <div className="fm-faculty-info">
                <div className="fm-faculty-name">{f.name}</div>
                <div className="fm-faculty-id">{f.id}</div>
                <div className="fm-faculty-email">{f.email}</div>
              </div>
              <div>
                <div className="fm-position">{f.position}</div>
                <div className="fm-experience">{f.experience}</div>
              </div>
              <div>{f.department}</div>
              <div className="fm-courses">📚 {f.courses}</div>
              <div className="fm-students">👥 {f.students}</div>
              <div className="fm-rating">⭐ {f.rating}</div>
              <div>
                {f.workload > 0 ? (
                  <>
                    <div className="fm-workload-bar">
                      <div className="fm-workload-fill" style={{width: `${f.workload}%`}}></div>
                    </div>
                    <div className="fm-workload-text">{f.workload}%</div>
                  </>
                ) : (
                  <span className="fm-workload-text">0%</span>
                )}
              </div>
              <div>
                <span className={`fm-status-badge ${f.status}`}>{f.status}</span>
              </div>
              <div className="fm-actions">
                <button className="fm-action-btn"><Mail size={16} /></button>
                <button className="fm-action-btn"><Phone size={16} /></button>
                <button className="fm-action-btn"><Clock size={16} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
    </div>
  );
};

export default FacultyManagement;