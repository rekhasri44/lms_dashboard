import React, { useState } from 'react';
import { MoreVertical, Download, Filter, Plus } from 'lucide-react';
import './CourseManagement.css';
import { 
  Bell, 
  User, 
  BarChart3, 
  BookOpen, 
  Users, 
  GraduationCap, 
  FileText, 
  Settings,
  Info,
  X,
  CheckCircle,
  AlertTriangle,
  Calendar
} from 'lucide-react';
const CourseManagement = () => {
  const [courses] = useState([
    {
      code: 'CS101',
      name: 'Introduction to Programming',
      department: 'Computer Science',
      credits: 4,
      instructor: 'Dr. Emily Thompson',
      schedule: 'MWF 10:00-11:00',
      enrolled: 125,
      capacity: 130,
      waitlist: 15,
      rating: 4.5,
      difficulty: 'Beginner',
      status: 'full'
    },
    {
      code: 'MATH201',
      name: 'Calculus II',
      department: 'Mathematics',
      credits: 4,
      instructor: 'Prof. Michael Davis',
      schedule: 'TTh 2:00-3:30',
      enrolled: 89,
      capacity: 120,
      waitlist: 0,
      rating: 4.2,
      difficulty: 'Intermediate',
      status: 'open'
    },
    {
      code: 'PHYS301',
      name: 'Quantum Mechanics',
      department: 'Physics',
      credits: 3,
      instructor: 'Dr. Lisa Park',
      schedule: 'MWF 1:00-2:00',
      enrolled: 45,
      capacity: 50,
      waitlist: 0,
      rating: 4.7,
      difficulty: 'Advanced',
      status: 'open'
    },
    {
      code: 'BIO150',
      name: 'Cell Biology',
      department: 'Biology',
      credits: 4,
      instructor: 'Prof. Robert Brown',
      schedule: 'TTh 10:00-11:30',
      enrolled: 98,
      capacity: 100,
      waitlist: 8,
      rating: 3.9,
      difficulty: 'Intermediate',
      status: 'nearly full'
    },
    {
      code: 'CHEM210',
      name: 'Organic Chemistry I',
      department: 'Chemistry',
      credits: 4,
      instructor: 'Dr. Amanda Wilson',
      schedule: 'MWF 9:00-10:00',
      enrolled: 87,
      capacity: 90,
      waitlist: 12,
      rating: 4.1,
      difficulty: 'Advanced',
      status: 'nearly full'
    }
  ]);

  return (
    <div className="course-management">
        <div className="sidebar">
                <div className="sidebar-header">
                  <div className="logo">
                    <div className="logo-icon">
                      <GraduationCap className="icon-medium" />
                    </div>
        
                 
                    
                  
                    <span className="logo-text">EduAdmin</span>
                  </div>
                </div>
                
                <nav className="sidebar-nav">
                  <div className="nav-section-title">
                    Navigation
                  </div>
                  <div className="nav-links">
                    <a href="/" className="nav-link active">
                      <BarChart3 className="nav-icon" />
                      Overview
                    </a>
                    <a href="/student" className="nav-link">
                      <Users className="nav-icon" />
                      Students
                    </a>
                    <a href="/faculty" className="nav-link">
                      <GraduationCap className="nav-icon" />
                      Faculty
                    </a>
                    <a href="/course" className="nav-link">
                      <BookOpen className="nav-icon" />
                      Courses
                    </a>
                  <a href="/analytics" className="nav-link">
                                <BarChart3 className="nav-icon" />
                                Analytics
                              </a>
                              <a href="/reports" className="nav-link">
                                <FileText className="nav-icon" />
                                Reports
                              </a>
                              <a href="/settings" className="nav-link">
                                <Settings className="nav-icon" />
                                Settings
                              </a>
                  </div>
                </nav>
              </div>
              <div className='right'>
              
            
      <div className="cm-header">
        <h1>Course Management</h1>
        <div className="cm-header-actions">
          <span className="notification-dot"></span>
          <div className="user-avatar"></div>
        </div>
      </div>

      <div className="cm-stats">
        <div className="cm-stat-card">
          <div className="cm-stat-label">Total Courses</div>
          <div className="cm-stat-value">486</div>
          <div className="cm-stat-change neutral">No change from last semester</div>
        </div>
        <div className="cm-stat-card">
          <div className="cm-stat-label">Active This Semester</div>
          <div className="cm-stat-value">324</div>
          <div className="cm-stat-change positive">↑ 5.2% from last semester</div>
        </div>
        <div className="cm-stat-card">
          <div className="cm-stat-label">Avg Enrollment</div>
          <div className="cm-stat-value">89%</div>
          <div className="cm-stat-change positive">↑ 3.1% from last semester</div>
        </div>
        <div className="cm-stat-card">
          <div className="cm-stat-label">High Demand</div>
          <div className="cm-stat-value">23</div>
          <div className="cm-stat-change positive">↑ 12.5% from last semester</div>
        </div>
      </div>

      <div className="cm-catalog">
        <div className="cm-catalog-header">
          <h2>Course Catalog</h2>
          <div className="cm-catalog-actions">
            <button className="cm-btn cm-btn-secondary">
              <Filter size={16} /> Filter
            </button>
            <button className="cm-btn cm-btn-secondary">
              <Download size={16} /> Export
            </button>
            <button className="cm-btn cm-btn-primary">
              <Plus size={16} /> Add Course
            </button>
          </div>
        </div>

        <div className="cm-search">
          <input type="text" placeholder="Search courses by code, name, or instructor..." />
        </div>

        <div className="cm-table">
          <div className="cm-table-header">
            <div>Course</div>
            <div>Instructor</div>
            <div>Schedule</div>
            <div>Enrollment</div>
            <div>Waitlist</div>
            <div>Rating</div>
            <div>Difficulty</div>
            <div>Status</div>
            <div>Actions</div>
          </div>
          {courses.map(course => (
            <div key={course.code} className="cm-table-row">
              <div className="cm-course-info">
                <div className="cm-course-code">{course.code}</div>
                <div className="cm-course-name">{course.name}</div>
                <div className="cm-course-meta">{course.department} • {course.credits} credits</div>
              </div>
              <div>{course.instructor}</div>
              <div className="cm-schedule">
                <Calendar size={14} /> {course.schedule}
              </div>
              <div>
                <div className="cm-enrollment-text">{course.enrolled}/{course.capacity}</div>
                <div className="cm-enrollment-bar">
                  <div className="cm-enrollment-fill" style={{width: `${(course.enrolled/course.capacity)*100}%`}}></div>
                </div>
                <div className="cm-enrollment-percent">{Math.round((course.enrolled/course.capacity)*100)}%</div>
              </div>
              <div className="cm-waitlist">{course.waitlist > 0 ? `⚠️ ${course.waitlist}` : '0'}</div>
              <div className="cm-rating">⭐ {course.rating}</div>
              <div>
                <span className={`cm-difficulty-badge ${course.difficulty.toLowerCase()}`}>
                  {course.difficulty}
                </span>
              </div>
              <div>
                <span className={`cm-status-badge ${course.status.replace(' ', '-')}`}>
                  {course.status}
                </span>
              </div>
              <div className="cm-actions">
                <button className="cm-action-btn"><Users size={16} /></button>
                <button className="cm-action-btn"><Calendar size={16} /></button>
                <button className="cm-action-btn"><MoreVertical size={16} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
      </div>
    </div>
  );
};

export default CourseManagement;